# PCAP Flow Analyzer

Deep TCP Stream Diagnostics & Packet Flow Visualization Platform.

This project is a 100% native Python web application that parses PCAP/PCAPNG files, analyzes TCP state machines, and visually renders packet flow anomalies—all with **zero external dependencies**. No Wireshark or `tcpdump` required.

## Features

- **Native PCAP/PCAPNG Parsing:** Decodes Little/Big-Endian, Nanosecond/Microsecond captures natively.
- **TCP Stream Reassembly & Diagnostics:** Detects packet loss, Fast Retransmits, RTOs, Zero-Window stalls, and connection RSTs.
- **Interactive Sequence Ladder:** Renders an animated SVG packet sequence diagram highlighting anomalies.
- **Performance Dashboards:** Plots Canvas-based RTT Latency, Window Sizes, and Throughput (KB/s).
- **Executive Health Score:** Automatically scores stream health (0-100) and provides root-cause remediation advice.

## Quickstart

Requires Python 3.10+ (Standard Library only, no `pip install` required!).

```bash
# Clone the repository
git clone https://github.com/yourusername/pcap-flow-analyzer.git
cd pcap-flow-analyzer

# Run the backend REST server & frontend UI
python3 server.py --port 8080
```

Open a web browser and navigate to `http://localhost:8080`.

## Architecture & Built-in Samples

The backend consists of:
- `engine/pcap_parser.py`: Zero-dependency native binary PCAP parser.
- `engine/tcp_analyzer.py`: Stateful TCP diagnostics and anomaly detection logic.
- `server.py`: Multi-threaded Python HTTP Server serving REST API endpoints.

The application comes pre-loaded with four synthetic captures demonstrating different anomalies (Packet Loss, Zero-Window, RST Aborts), which you can access from the dropdown in the UI.

## License
MIT License.
