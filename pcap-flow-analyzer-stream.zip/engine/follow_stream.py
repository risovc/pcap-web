def format_hex_dump(data: bytes, offset: int = 0) -> str:
    lines = []
    for i in range(0, len(data), 16):
        chunk = data[i : i + 16]
        hex_bytes = " ".join(f"{b:02x}" for b in chunk)
        ascii_chars = "".join(chr(b) if 32 <= b <= 126 else "." for b in chunk)
        lines.append(f"{(i+offset):08x}   {hex_bytes:<48}   {ascii_chars}")
    return "\n".join(lines)

def extract_stream_from_packets(packets, client_ip: str, client_port: int, server_ip: str, server_port: int) -> list:
    c_pkts = []
    s_pkts = []
    
    for p in packets:
        if not p.is_tcp: continue
        if p.tcp.payload_len == 0: continue
        
        src_ip = p.ip.src_ip
        dst_ip = p.ip.dst_ip
        src_port = p.tcp.src_port
        dst_port = p.tcp.dst_port
        
        if src_ip == client_ip and src_port == client_port and dst_ip == server_ip and dst_port == server_port:
            c_pkts.append(('C->S', p.tcp.seq_num, p.tcp.payload, p.timestamp))
        elif src_ip == server_ip and src_port == server_port and dst_ip == client_ip and dst_port == client_port:
            s_pkts.append(('S->C', p.tcp.seq_num, p.tcp.payload, p.timestamp))

    def reassemble(pkts):
        pkts.sort(key=lambda x: x[1])  # sort by seq_num
        chunks = []
        curr_seq = None
        for _, seq, payload, ts in pkts:
            if curr_seq is None:
                chunks.append({'seq': seq, 'payload': payload, 'ts': ts})
                curr_seq = seq + len(payload)
            else:
                if seq == curr_seq:
                    chunks[-1]['payload'] += payload
                    curr_seq += len(payload)
                elif seq < curr_seq:
                    overlap = curr_seq - seq
                    if overlap < len(payload):
                        chunks[-1]['payload'] += payload[overlap:]
                        curr_seq += len(payload[overlap:])
                else:
                    gap_size = seq - curr_seq
                    gap_msg = f"\n[... MISSING {gap_size} BYTES ...]\n".encode('ascii')
                    chunks.append({'seq': seq, 'payload': gap_msg + payload, 'ts': ts})
                    curr_seq = seq + len(payload)
        return chunks

    c2s_chunks = reassemble(c_pkts)
    s2c_chunks = reassemble(s_pkts)
    
    all_chunks = []
    for c in c2s_chunks:
        all_chunks.append({'direction': 'C->S', 'raw': c['payload'], 'timestamp': c['ts']})
    for c in s2c_chunks:
        all_chunks.append({'direction': 'S->C', 'raw': c['payload'], 'timestamp': c['ts']})
        
    all_chunks.sort(key=lambda x: x['timestamp'])
    
    import re
    
    curr_offset = 0
    for chunk in all_chunks:
        raw_bytes = chunk['raw']
        
        try:
            text = raw_bytes.decode('utf-8')
        except UnicodeDecodeError:
            text = raw_bytes.decode('latin-1')
        text = re.sub(r'[^\x09\x0A\x0D\x20-\x7E]', '.', text)
        
        chunk['data_ascii'] = text
        chunk['data_hex'] = format_hex_dump(raw_bytes, curr_offset)
        chunk['data'] = text  # fallback default
        
        curr_offset += len(raw_bytes)
        del chunk['raw']
            
    return all_chunks
