---
name: spanner-event-readiness-checker
description: Cloud Spanner Event Readiness Expert Agent. Use this skill when the user asks to run an Event Readiness check, pre-event health check, capacity assessment, or production verification for Google Cloud Spanner instances and databases. Checks CPU utilization (65% single-region, 45% multi-region), autoscaler sizing, storage limits (4 TB/node), managed backup schedules, query optimizer version pinning, pre-splitting, and 7d/30d Monarch telemetry.
---

# Cloud Spanner Event Readiness Checker

Expert automated agent for conducting **Cloud Spanner Event Readiness Evaluations**, assessing production topology, capacity sizing, autoscaling configurations, and 7-day / 30-day Cloud Monarch telemetry.

## Quick Start

### 1. Interactive Web Dashboard
```bash
python3 /usr/local/google/home/risov/.gemini/jetski/scratch/spanner-event-readiness-checker/readiness_checker.py --web --port=8080
```
Open `http://localhost:8080` in your browser. Enter Customer Project ID, Justification (Bug ID e.g. `541322397` or Vector Case `vector/51234567`), and run the automated check.

### 2. CLI Execution
```bash
# Evaluate project and print internal support report with links
python3 /usr/local/google/home/risov/.gemini/jetski/scratch/spanner-event-readiness-checker/readiness_checker.py \
  --project="customer-project-id" \
  --justification="b/541322397"

# Publish official Dual-Tab Google Doc deliverable
python3 /usr/local/google/home/risov/.gemini/jetski/scratch/spanner-event-readiness-checker/readiness_checker.py \
  --project="customer-project-id" \
  --justification="vector/51234567" \
  --publish-gdoc

# Output customer-shareable external report only
python3 /usr/local/google/home/risov/.gemini/jetski/scratch/spanner-event-readiness-checker/readiness_checker.py \
  --project="customer-project-id" \
  --justification="b/541322397" \
  --external-only
```

---

## 14-Point Evaluation Criteria

The tool verifies every instance and database against the official Google Cloud Spanner Event Readiness Playbook:

1. **Instance Configuration & Topology**: Regional (`regional-us-central1`, 99.99% SLA) vs Dual-Region / Multi-Region (`nam3`, `eur3`, `nam-eur-asia1`, 99.999% SLA).
2. **Total CPU Utilization (7d & 30d)**:
   - Regional: `<= 65%`
   - Multi-Region / Dual-Region: `<= 45%` (reserves 55% failover headroom for leader/witness failover).
3. **High-Priority CPU Utilization (7d & 30d)**:
   - Regional: `<= 65%`
   - Multi-Region: `<= 45%`
4. **Compute Capacity & Autoscaling**:
   - Autoscaling (`autoscalingConfig`) with `minNodes`/`maxNodes` or `minProcessingUnits`/`maxProcessingUnits` vs fixed compute capacity.
5. **30-Day Peak Sizing & Headroom**:
   - Recommends max nodes based on Monarch `recommended_max_nodes` or 1.5x headroom over 30-day peak required capacity.
6. **Storage Utilization & Capacity**:
   - Target `<= 70%` (max 4 TB per node / 400 GB per 100 PUs).
7. **Database State & Dialect**:
   - Google Standard SQL vs PostgreSQL. Database operational state (`READY`).
8. **Query Optimizer Version & Statistics Pinning**:
   - Recommends pinning `optimizer_version` and `optimizer_statistics_package` prior to major traffic events to guarantee query plan stability.
9. **Managed Backups & Automated Backup Schedules**:
   - Checks active database backup schedules (`gcloud spanner backup-schedules list`) and existing backups (`gcloud spanner backups list`).
10. **Client Session Pre-warming**:
    - Recommends batch session creation ("SELECT 1" warmup queries) before event start to prevent session-creation latency storms.
11. **Table Pre-splitting**:
    - Recommends pre-splitting high-throughput tables 12 hours to 7 days prior to traffic surges.
12. **Client-Side Metrics (CSM) Coverage**:
    - Validates client telemetry and feature flag metrics.
13. **Cold Start Risk Detection**:
    - Evaluates 7-day minimum QPS (`min_qps_7d < 10 QPS` flag).
14. **API Errors & Aborted Transactions**:
    - Evaluates `spanner.googleapis.com/api/request_count` (DEADLINE_EXCEEDED, UNAVAILABLE, RESOURCE_EXHAUSTED, and ABORTED transaction rates).

---

## Deliverables Generated

1. **Native Google Doc Deliverable** (`--publish-gdoc`):
   - Created via `/google/bin/releases/gemini-agents-gdocs/gdocs mutate import-md`.
   - Dual-tab / dual-section structure: External Customer Deliverable + Internal TSG/Support Engineering Checklist with Automon and Query Explorer links.
2. **Local Markdown Report** (`spanner_readiness_report_<project_id>.md`):
   - Transposed multi-instance matrix table.
   - Actionable recommendations with step-by-step remediation commands.
