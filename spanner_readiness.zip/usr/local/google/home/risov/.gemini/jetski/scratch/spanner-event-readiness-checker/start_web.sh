#!/usr/bin/env bash
set -e
PORT=${1:-8080}
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "🚀 Starting Cloud Spanner Event Readiness Dashboard on port ${PORT}..."
exec python3 "${DIR}/readiness_checker.py" --web --port="${PORT}"
