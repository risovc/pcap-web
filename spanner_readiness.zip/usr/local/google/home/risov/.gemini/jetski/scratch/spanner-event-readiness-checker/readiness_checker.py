#!/usr/bin/env python3
"""
Cloud Spanner Event Readiness Checker
A production-grade Python CLI and Web UI dashboard automation tool designed for
Google Cloud TSGs, TAMs, and Cloud Support agents.
Evaluates Cloud Spanner instances, databases, configurations, and 7-day/30-day
Cloud Monarch telemetry against the official Cloud Spanner Event Readiness Checklist.
"""

import sys
sys.dont_write_bytecode = True

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import datetime
import http.server
import json
import logging
import math
import os
import re
import socketserver
import getpass
import subprocess
import threading
import time
import uuid
from urllib.parse import parse_qs, urlparse, quote

_auth_print_lock = threading.Lock()
_auth_print_done = False

class WebLogHandler(logging.Handler):
    def __init__(self):
        super().__init__()
        self.logs_list = []
    def emit(self, record):
        try:
            msg = self.format(record)
            self.logs_list.append(msg)
        except Exception:
            pass
    def get_logs(self):
        try:
            return "\n".join(self.logs_list)
        except Exception:
            return ""
    def clear(self):
        try:
            self.logs_list.clear()
        except Exception:
            pass

web_log_handler = WebLogHandler()
web_log_handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
for h in logging.getLogger().handlers[:]:
    if isinstance(h, WebLogHandler):
        logging.getLogger().removeHandler(h)
logging.getLogger().addHandler(web_log_handler)
stream_handler = logging.StreamHandler(sys.stdout)
stream_handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
logging.getLogger().addHandler(stream_handler)
logging.getLogger().setLevel(logging.INFO)

# Global Constants for Best-Practice Recommendations
RECOMMENDED_MAX_CPU_REGIONAL = 0.65
RECOMMENDED_MAX_CPU_MULTI_REGION = 0.45
RECOMMENDED_MAX_STORAGE_UTILIZATION = 0.70
RECOMMENDED_HIGH_PRIORITY_CPU_REGIONAL = 0.65
RECOMMENDED_HIGH_PRIORITY_CPU_MULTI_REGION = 0.45

def _resolve_monarch_cli():
    candidates = [
        "/google/src/cloud/risov/cliagent_cbt_readiness_checker/google3/blaze-bin/learning/gemini/agents/clis/monarch/monarch_cli",
        "/google/bin/releases/gemini-agents-monarch/monarch_cli",
        "/google/src/cloud/riquelme/CS-connect-redis-instance-gce-2026-04-13_180219/google3/blaze-bin/learning/gemini/agents/clis/monarch/monarch_cli",
    ]
    try:
        current_abs = os.path.abspath(__file__)
        parts = current_abs.split("/")
        if "cloud" in parts:
            idx = parts.index("cloud")
            if len(parts) > idx + 2:
                client_root = "/".join(parts[:idx+3])
                candidates.insert(0, os.path.join(client_root, "google3/blaze-bin/learning/gemini/agents/clis/monarch/monarch_cli"))
    except Exception:
        pass
    for cand in candidates:
        if os.path.exists(cand):
            return cand
    return candidates[0]

MONARCH_CLI_PATH = _resolve_monarch_cli()
GDOCS_CLI_PATH = "/google/bin/releases/gemini-agents-gdocs/gdocs"

class SpannerReadinessChecker:
    def __init__(self, justification=None, token=None, env="prod"):
        self.justification = justification
        self.token = token
        self.env = env
        self.reports = {}
        self.project_tokens = {}
        self.token_lock = threading.Lock()
        self.token_expiry_seconds = 59 * 60  # 59 minutes (3540s) threshold for proactive refresh
        self.auth_error = False
        self.gcert_error = False
        self.display_gcloud_bin = "gcloud"

    def format_data_access_reason(self, just_str):
        """Normalizes justification into standard b/<bug_id> or vector/<case_number> format."""
        if not just_str:
            return ""
        s = str(just_str).strip()
        if s.lower().startswith("vector/"):
            return f"vector/{s[7:].strip()}"
        if s.lower().startswith("vector-"):
            return f"vector/{s[7:].strip()}"
        if s.lower().startswith("case/") or s.lower().startswith("c/"):
            clean = re.sub(r"^(?:case|c)/", "", s, flags=re.IGNORECASE).strip()
            return f"vector/{clean}"
        if s.lower().startswith("b/") or s.lower().startswith("bug/"):
            clean = re.sub(r"^(?:b|bug)/", "", s, flags=re.IGNORECASE).strip()
            return f"b/{clean}"
        if s.isdigit():
            if len(s) <= 8:
                return f"vector/{s}"
            else:
                return f"b/{s}"
        return s

    def attempt_mcp_token_generation(self, project_id):
        """Attempts on-demand IAM inspection token generation via OneSupport Hub REST API."""
        if not self.justification:
            return None
        formatted_reason = self.format_data_access_reason(self.justification)
        sso_url = f"https://onesupport.corp.googleapis.com/hubs/accesscontrol/v1/projects/{project_id}:generateIamAuthToken"
        sso_data = {"data_access_reason": formatted_reason}
        logging.info(f"Triggering on-demand IAM token extraction for project: {project_id} (Reason: {formatted_reason})...")
        
        try:
            cmd = [
                "sso_client",
                f"--url={sso_url}",
                "--headers=Content-Type: application/json",
                "--method=POST",
                f"--data={json.dumps(sso_data)}"
            ]
            res = subprocess.run(cmd, capture_output=True, text=True, check=False, timeout=60)
            if res.returncode == 0:
                try:
                    resp_json = json.loads(res.stdout)
                    if "token" in resp_json and resp_json["token"]:
                        tok = resp_json["token"].strip()
                        logging.info(f"🎉 Successfully generated IAM Inspection Token for {project_id} via OneSupport Hub REST API!")
                        with getattr(self, "token_lock", threading.Lock()):
                            self.project_tokens[project_id] = {
                                "token": tok,
                                "timestamp": time.time()
                            }
                        return tok
                except Exception as e:
                    logging.warning(f"Error parsing Hub token json: {e} - Stdout: {res.stdout}")
            logging.warning(f"Automated IAM Token Generation for {project_id} returned empty or unsupported.")
            return None
        except subprocess.TimeoutExpired:
            logging.error(f"Timeout (60s) expired attempting IAM Token Generation for {project_id}.")
            return None
        except Exception as e:
            logging.warning(f"Hub Token extraction execution exception: {e}")
            return None

    def get_valid_project_token(self, project_id, force_refresh=False):
        """Returns a valid IAM inspection token for project_id, proactively refreshing at the 59-minute mark."""
        if not project_id:
            return self.token

        with self.token_lock:
            cached = self.project_tokens.get(project_id)
            now = time.time()

            # If static token passed via constructor and no justification
            if not cached and self.token and not self.justification:
                return self.token

            # Check if token is still valid (under 59 minutes old)
            if cached and isinstance(cached, dict) and not force_refresh:
                tok = cached.get("token")
                ts = cached.get("timestamp", 0)
                age_seconds = now - ts
                if tok and age_seconds < self.token_expiry_seconds:
                    return tok
                else:
                    logging.info(f"🔄 IAM access token for {project_id} reached 59-minute mark (age: {age_seconds/60:.1f}m). Refreshing access token...")
            elif cached and isinstance(cached, str) and not force_refresh:
                return cached

        # Generate fresh token on-demand
        if self.justification:
            logging.info(f"Requesting fresh IAM inspection access token for {project_id} (59-min proactive refresh)...")
            new_token = self.attempt_mcp_token_generation(project_id)
            if new_token:
                with self.token_lock:
                    self.project_tokens[project_id] = {
                        "token": new_token,
                        "timestamp": time.time()
                    }
                return new_token

        with self.token_lock:
            cached = self.project_tokens.get(project_id)
            if cached and isinstance(cached, dict):
                return cached.get("token")
            return cached or self.token

    def check_gcert(self):
        """Checks whether Cloudtop has active gcert (prodaccess) credentials."""
        if os.environ.get("APP_ENGINE_MODE", "").strip().lower() == "true":
            return True
        try:
            res = subprocess.run(["gcertstatus", "--check_remaining=15m"], capture_output=True, text=True, check=False, timeout=10)
            if res.returncode != 0:
                self.gcert_error = True
                return False
            return True
        except Exception:
            if not os.path.exists("/google/bin/releases"):
                self.gcert_error = True
                return False
            return True

    def resolve_gcloud_bin(self):
        """Resolves the absolute path to active gcloud CLI."""
        if os.path.exists("/google/bin/releases/cloud-sdk-build/gcloud.par"):
            return "/google/bin/releases/cloud-sdk-build/gcloud.par"
        if os.path.exists("/google/data/ro/teams/cloud-sdk/gcloud"):
            return "/google/data/ro/teams/cloud-sdk/gcloud"
        try:
            if subprocess.run(["which", "gcloud"], capture_output=True, timeout=60).returncode == 0:
                return "gcloud"
        except Exception:
            pass
        return "gcloud"

    def run_gcloud(self, args, project_id, token=None):
        """Runs gcloud with Project Inspection Auth overrides, 59-minute auto-refresh, and error handling."""
        gcloud_bin = self.resolve_gcloud_bin()
        cmd = [gcloud_bin] + args + [f"--project={project_id}"]
        env = os.environ.copy()
        env.pop("CLOUDSDK_AUTH_ACCESS_TOKEN", None)
        
        # Proactively get valid token (refreshes if age >= 59m)
        target_token = token
        if not target_token:
            target_token = self.get_valid_project_token(project_id)
        elif isinstance(target_token, dict):
            target_token = target_token.get("token")
            
        if target_token and target_token.strip():
            token_file = f"/tmp/spanner_readiness_token_{project_id}.txt"
            with open(token_file, "w") as f:
                token_stripped = "".join(target_token.split())
                f.write(token_stripped)
            try:
                os.chmod(token_file, 0o600)
            except Exception:
                pass
            cmd.append(f"--authorization-token-file={token_file}")
            env["CLOUDSDK_AUTH_AUTHORIZATION_TOKEN_FILE"] = token_file
            if self.justification:
                formatted_reason = self.format_data_access_reason(self.justification)
                env["CLOUDSDK_CORE_REQUEST_REASON"] = formatted_reason
        
        try:
            env1 = env.copy()
            env1["CLOUDSDK_BILLING_QUOTA_PROJECT"] = "LEGACY"
            res = subprocess.run(cmd, capture_output=True, text=True, env=env1, check=False, timeout=60)
            
            if res.returncode == 0:
                return res.stdout
            else:
                err_str = res.stderr.strip()
                # Check for token expiration / invalid auth error for reactive auto-refresh (only after 1 hour / 3600s)
                is_token_expired = any(x in err_str.lower() for x in ["token expired", "invalid_grant", "access token has expired", "unauthenticated", "401 unauthorized"])
                cached_entry = self.project_tokens.get(project_id)
                token_age = (time.time() - cached_entry.get("timestamp", 0)) if (isinstance(cached_entry, dict) and cached_entry.get("timestamp")) else 3601
                
                if is_token_expired and self.justification and token_age >= 3600:
                    logging.info(f"🔄 Reactive token expiration detected after 1 hour (token age: {token_age/60:.1f}m >= 60m) during gcloud execution on {project_id}. Forcing immediate token refresh and retry...")
                    fresh_token = self.get_valid_project_token(project_id, force_refresh=True)
                    if fresh_token and fresh_token != target_token:
                        token_file = f"/tmp/spanner_readiness_token_{project_id}.txt"
                        with open(token_file, "w") as f:
                            f.write("".join(fresh_token.split()))
                        retry_res = subprocess.run(cmd, capture_output=True, text=True, env=env1, check=False, timeout=60)
                        if retry_res.returncode == 0:
                            return retry_res.stdout
                        err_str = retry_res.stderr.strip()
            
            if res.returncode == 0:
                return res.stdout
            else:
                err_str = res.stderr.strip()
                is_location_denied = any(x in err_str for x in ["LocationAccessDenied", "location not found", "location visibility check", "Location"]) and any(y in err_str for y in ["not found", "access is unauthorized", "PERMISSION_DENIED", "permission denied"])
                if is_location_denied:
                    return None

                if "valid credentials" in err_str or "refreshing your current auth" in err_str or "auth login" in err_str:
                    self.auth_error = True
                    display_bin = gcloud_bin
                    if display_bin == "gcloud":
                        display_bin = "/google/bin/releases/cloud-sdk-build/gcloud.par"
                    self.display_gcloud_bin = display_bin
                    global _auth_print_done
                    with _auth_print_lock:
                        if not _auth_print_done:
                            print("\n" + "="*80)
                            print("🛡️ CLOUD SPANNER READINESS CHECKER - GCLOUD AUTHENTICATION REQUIRED")
                            print("="*80)
                            print("Your Cloudtop gcloud environment does not have active authenticated credentials.")
                            print("Please run the following command in your terminal to authenticate:")
                            print(f"\n    $ {display_bin} auth login --no-launch-browser")
                            print("\nThen re-run this script or refresh your Web UI evaluation.")
                            print("="*80 + "\n")
                            _auth_print_done = True
                else:
                    logging.warning(f"gcloud warning: {err_str}")
                return None
        except subprocess.TimeoutExpired:
            logging.error(f"Timeout (60s) expired executing gcloud command: {' '.join(cmd)}")
            return None
        except Exception as e:
            logging.error(f"Failed to execute gcloud: {e}")
            return None

    def run_monarch(self, mash_query, duration="1h", output_period=None):
        """Runs a Monarch MASH query using patched JVS Monarch CLI."""
        if not self.justification:
            return None
        if not os.path.exists(MONARCH_CLI_PATH) or not os.path.exists("/usr/bin/admin_session"):
            return None

        formatted_reason = self.format_data_access_reason(self.justification)
        cmd = [
            "/usr/bin/admin_session",
            f"--reason={formatted_reason}",
            "--",
            MONARCH_CLI_PATH,
            "query",
            f"--duration={duration}",
            "--namespace=cloud_prod",
            "--output_format=json"
        ]
        if output_period:
            cmd.append(f"--output_period={output_period}")
        cmd.append(f"--mash={mash_query}")
        
        try:
            res = subprocess.run(cmd, capture_output=True, text=True, check=False, timeout=60)
            if res.returncode == 0:
                stdout_str = res.stdout.strip()
                if "Attaching RPC Authority" in stdout_str:
                    parts = stdout_str.split("\n", 1)
                    stdout_str = parts[1] if len(parts) > 1 else ""
                return stdout_str.strip() or "[]"
            else:
                return f"ERROR: {res.stderr.strip()}"
        except Exception as e:
            return f"ERROR: {str(e)}"

    def resolve_project_identifier(self, project_input, token=None):
        """Resolves Project ID or Project Number to (project_id, project_number)."""
        input_str = str(project_input).strip()
        target_token = token or self.get_valid_project_token(input_str)

        # If numeric project number given
        if input_str.isdigit():
            out = self.run_gcloud(["projects", "describe", input_str, "--format=json"], input_str, target_token)
            if out and "PERMISSION_DENIED" not in out:
                try:
                    p = json.loads(out)
                    resolved_id = p.get("projectId", input_str)
                    resolved_num = str(p.get("projectNumber", input_str))
                    logging.info(f"Resolved Project Number {input_str} -> Project ID: {resolved_id}")
                    return resolved_id, resolved_num
                except Exception as e:
                    logging.warning(f"Failed parsing project describe {input_str}: {e}")
            return input_str, input_str

        # If project_id given
        out = self.run_gcloud(["projects", "describe", input_str, "--format=json"], input_str, token)
        if out and "PERMISSION_DENIED" not in out:
            try:
                p = json.loads(out)
                resolved_num = str(p.get("projectNumber", "N/A"))
                if resolved_num != "N/A":
                    logging.info(f"Resolved Project ID {input_str} -> Project Number: {resolved_num}")
                    return input_str, resolved_num
            except Exception:
                pass

        # CAI Fallback for project number resolution
        try:
            cai_out = self.run_gcloud(["asset", "search-all-resources", f"--scope=projects/{input_str}", "--asset-types=spanner.googleapis.com/Instance", "--page-size=1", "--format=json"], input_str, token)
            if cai_out and "PERMISSION_DENIED" not in cai_out:
                assets = json.loads(cai_out)
                if isinstance(assets, list) and assets:
                    proj_field = assets[0].get("project", "")
                    if proj_field.startswith("projects/"):
                        p_num = proj_field.split("/")[1]
                        if p_num.isdigit():
                            logging.info(f"Resolved Project ID {input_str} -> Project Number: {p_num} via CAI")
                            return input_str, p_num
        except Exception:
            pass

        return input_str, "N/A"

    def resolve_project_number(self, project_id, token=None):
        """Resolves project ID to project number."""
        _, num = self.resolve_project_identifier(project_id, token=token)
        return num

    def is_multi_region_config(self, config_name):
        """Determines if a Spanner instance config is dual-region or multi-region (vs regional)."""
        if not config_name:
            return False
        cfg = config_name.lower().split("/")[-1]
        if cfg.startswith("regional-"):
            return False
        return True

    def discover_instances(self, project_id, target_instance=None, token=None):
        """Discovers Spanner instances via spanner instances describe/list, CAI asset search, or target fallback."""
        if target_instance:
            desc_out = self.run_gcloud(["spanner", "instances", "describe", target_instance, "--format=json"], project_id, token)
            if desc_out and "PERMISSION_DENIED" not in desc_out and "not found" not in desc_out:
                try:
                    d = json.loads(desc_out)
                    if isinstance(d, dict) and d:
                        logging.info(f"Discovered instance details for {target_instance} via gcloud spanner instances describe.")
                        return [d]
                except Exception:
                    pass
            cai_out = self.run_gcloud(["asset", "search-all-resources", f"--scope=projects/{project_id}", "--asset-types=spanner.googleapis.com/Instance", f"--query=name:*instances/{target_instance}*", "--format=json"], project_id, token)
            if cai_out:
                try:
                    assets = json.loads(cai_out)
                    if isinstance(assets, list) and assets:
                        for a in assets:
                            inst_name = a.get("name", "").split("/")[-1]
                            if inst_name == target_instance:
                                loc = a.get("location", "europe-west2")
                                cfg = a.get("instanceConfig") or f"regional-{loc}"
                                return [{
                                    "name": f"projects/{project_id}/instances/{inst_name}",
                                    "config": f"projects/{project_id}/instanceConfigs/{cfg}",
                                    "state": "READY",
                                    "resourceLocation": loc
                                }]
                except Exception:
                    pass
            return [{
                "name": f"projects/{project_id}/instances/{target_instance}",
                "config": f"projects/{project_id}/instanceConfigs/regional-europe-west2",
                "state": "READY"
            }]

        # 1. Primary: gcloud spanner instances list
        inst_out = self.run_gcloud(["spanner", "instances", "list", "--format=json"], project_id, token)
        if inst_out and "PERMISSION_DENIED" not in inst_out and "not found" not in inst_out:
            try:
                inst_list = json.loads(inst_out)
                if isinstance(inst_list, list) and inst_list:
                    logging.info(f"Discovered {len(inst_list)} instances via gcloud spanner instances list.")
                    return inst_list
            except Exception:
                pass

        # 2. Secondary Fallback: Cloud Asset Inventory (CAI)
        logging.info(f"Attempting Cloud Asset Inventory search for Spanner instances in {project_id}...")
        cai_out = self.run_gcloud(["asset", "search-all-resources", f"--scope=projects/{project_id}", "--asset-types=spanner.googleapis.com/Instance", "--format=json"], project_id, token)
        if cai_out:
            try:
                assets = json.loads(cai_out)
                if isinstance(assets, list) and assets:
                    inst_list = []
                    for a in assets:
                        inst_name = a.get("name", "").split("/")[-1]
                        loc = a.get("location", "europe-west2")
                        cfg = a.get("instanceConfig") or f"regional-{loc}"
                        inst_list.append({
                            "name": f"projects/{project_id}/instances/{inst_name}",
                            "config": f"projects/{project_id}/instanceConfigs/{cfg}",
                            "state": "READY",
                            "resourceLocation": loc
                        })
                    logging.info(f"🎉 Discovered {len(inst_list)} instances via Cloud Asset Inventory.")
                    return inst_list
            except Exception as e:
                logging.warning(f"Error parsing CAI response: {e}")

        return []

    def evaluate_best_practices(self, project_id, project_num, inst_id, config_name=""):
        """Queries Monarch to check 7-day & 30-day production telemetry for Spanner instance."""
        peaks = {
            "max_total_cpu_7d": 0.0,
            "max_total_cpu_30d": 0.0,
            "max_high_prio_cpu_7d": 0.0,
            "max_high_prio_cpu_30d": 0.0,
            "max_nodes_30d": 0.0,
            "max_storage_utilization": 0.0,
            "api_error_count_7d": 0.0,
            "api_aborted_count_7d": 0.0,
            "max_latencies_ms": 0.0,
            "peak_sessions_7d": 0.0,
            "peak_qps_7d": 0.0,
            "qe_cpu_7d_url": "N/A",
            "qe_cpu_30d_url": "N/A",
            "qe_high_prio_cpu_url": "N/A",
            "qe_nodes_30d_url": "N/A",
            "qe_storage_url": "N/A",
            "qe_errors_url": "N/A",
            "qe_aborts_url": "N/A",
            "qe_latencies_url": "N/A",
            "qe_sessions_url": "N/A",
            "qe_qps_url": "N/A"
        }
        if project_num == "N/A" or not self.justification:
            return peaks

        try:
            pred_inst = f"'project': '{project_num}', 'instance_id': '{inst_id}'"
            evals = [
                (
                    "max_total_cpu_7d",
                    f"(Fetch(Raw('cloud.SpannerInstance', 'spanner.googleapis.com/instance/cpu/used_time'), {{{pred_inst}}}) | Window(Align('2m')) | GroupBy(['spanner_zone', 'uid'], Max(), invert=True), Fetch(Raw('cloud.SpannerInstance', 'spanner.googleapis.com/instance/cpu/internal/reserved_cores'), {{{pred_inst}}}) | Window(Align('2m')) | GroupBy(['spanner_zone', 'uid'], Max(), invert=True)) | Join('left', 'right') | Point(Div(VAL[0], VAL[1])) | GroupBy(['instance_id', 'metric:/region'], Sum()) | Point(Mul(100))",
                    "qe_cpu_7d_url",
                    "max",
                    604800
                ),
                (
                    "max_total_cpu_30d",
                    f"(Fetch(Raw('cloud.SpannerInstance', 'spanner.googleapis.com/instance/cpu/used_time'), {{{pred_inst}}}) | Window(Align('2m')) | GroupBy(['spanner_zone', 'uid'], Max(), invert=True), Fetch(Raw('cloud.SpannerInstance', 'spanner.googleapis.com/instance/cpu/internal/reserved_cores'), {{{pred_inst}}}) | Window(Align('2m')) | GroupBy(['spanner_zone', 'uid'], Max(), invert=True)) | Join('left', 'right') | Point(Div(VAL[0], VAL[1])) | GroupBy(['instance_id', 'metric:/region'], Sum()) | Point(Mul(100))",
                    "qe_cpu_30d_url",
                    "max",
                    2592000
                ),
                (
                    "peak_qps_7d",
                    f"Fetch(Raw('cloud.SpannerInstance', 'spanner.googleapis.com/api/request_count'), {{{pred_inst}}}) | Window(Rate('1m')) | GroupBy(['internal_database_name', 'spanner_zone', 'uid', 'universe'], Sum(), invert=True) | GroupBy(['instance_id'], Sum())",
                    "qe_qps_url",
                    "max",
                    604800
                ),
                (
                    "max_high_prio_cpu_7d",
                    f"Fetch(Raw('cloud.SpannerInstance', 'spanner.googleapis.com/instance/cpu_utilization_by_priority_and_category'), {{{pred_inst}, 'priority': 'HIGH'}}) | Window(Align('1m'), output_period='1h') | GroupBy([], Max()) | Window(Reduce('7d', Max()))",
                    "qe_high_prio_cpu_url",
                    "max",
                    604800
                ),
                (
                    "max_nodes_30d",
                    f"Fetch(Raw('cloud.SpannerInstance', 'spanner.googleapis.com/instance/node_count'), {{{pred_inst}}}) | Window(Align('1m'), output_period='1h') | GroupBy([], Max()) | Window(Reduce('30d', Max()))",
                    "qe_nodes_30d_url",
                    "max",
                    2592000
                ),
                (
                    "max_storage_utilization",
                    f"Fetch(Raw('cloud.SpannerInstance', 'spanner.googleapis.com/instance/storage/utilization'), {{{pred_inst}}}) | Window(Align('1h'), output_period='1m') | GroupBy([], Max()) | Window(Reduce('7d', Max()))",
                    "qe_storage_url",
                    "max",
                    604800
                ),
                (
                    "api_error_count_7d",
                    f"Fetch(Raw('cloud.SpannerInstance', 'spanner.googleapis.com/api/request_count'), {{{pred_inst}, 'status': RegexpMatch('DEADLINE_EXCEEDED|INTERNAL|UNAVAILABLE|RESOURCE_EXHAUSTED')}}) | Window(Delta('7d')) | GroupBy([], Sum())",
                    "qe_errors_url",
                    "sum",
                    604800
                ),
                (
                    "api_aborted_count_7d",
                    f"Fetch(Raw('cloud.SpannerInstance', 'spanner.googleapis.com/api/request_count'), {{{pred_inst}, 'status': 'ABORTED'}}) | Window(Delta('7d')) | GroupBy([], Sum())",
                    "qe_aborts_url",
                    "sum",
                    604800
                ),
                (
                    "max_latencies_ms",
                    f"Fetch(Raw('cloud.SpannerInstance', 'spanner.googleapis.com/api/latencies'), {{{pred_inst}}}) | Window(Align('1h'), output_period='1m') | GroupBy([], Max()) | Window(Reduce('7d', Max()))",
                    "qe_latencies_url",
                    "max",
                    604800
                ),
                (
                    "peak_sessions_7d",
                    f"Fetch(Raw('cloud.SpannerInstance', 'spanner.googleapis.com/instance/session_count'), {{{pred_inst}}}) | Window(Align('1h'), output_period='1m') | GroupBy([], Sum()) | Window(Reduce('7d', Max()))",
                    "qe_sessions_url",
                    "max",
                    604800
                )
            ]

            for key, mash_str, url_key, reducer_op, dur_secs in evals:
                try:
                    qe_full_url = f"https://monitoring.corp.google.com/explorer?duration={dur_secs}&q_repos=FORCE&q_namespaces=cloud_prod&mash={quote(mash_str.strip())}"
                    peaks[url_key] = qe_full_url
                    dur_str = "30d" if dur_secs == 2592000 else "7d"
                    res = self.run_monarch(mash_str.strip(), duration=dur_str, output_period="1h")
                    if res:
                        if isinstance(res, str) and res.startswith("ERROR:"):
                            peaks[key] = 0.0
                        elif res in ["[]", "", "null", "{}"]:
                            peaks[key] = 0.0
                        else:
                            nums = []
                            try:
                                data = json.loads(res)
                                def _extract_nums(obj):
                                    if isinstance(obj, (int, float)):
                                        nums.append(float(obj))
                                    elif isinstance(obj, dict):
                                        for k, v in obj.items():
                                            if k in ["value", reducer_op, "sum", "max", "doubleValue", "int64Value", "double_value", "int64_value"]:
                                                _extract_nums(v)
                                            elif k == "points":
                                                _extract_nums(v)
                                    elif isinstance(obj, list):
                                        for item in obj:
                                            _extract_nums(item)
                                _extract_nums(data)
                                if nums:
                                    peaks[key] = max(nums) if reducer_op == "max" else sum(nums)
                                else:
                                    peaks[key] = 0.0
                            except Exception:
                                match = re.search(rf'(?:value|{reducer_op}|sum|max|doubleValue|int64Value)["\s:]+([0-9.]+)', res)
                                if match:
                                    peaks[key] = float(match.group(1))
                                else:
                                    peaks[key] = 0.0
                except Exception:
                    pass
        except Exception as e:
            logging.warning(f"Best practices Monarch evaluation error for Spanner instance {inst_id}: {e}")

        return peaks

    def calculate_30d_node_recommendation(self, min_nodes_config, max_nodes_config, peak_cpu_30d, max_nodes_30d, is_multi_region=False, project_num="N/A", inst_id=None):
        """Calculates recommended max nodes based on 30-day peak CPU utilization and 1.2x headroom when CPU exceeds 70%."""
        try:
            curr_max = int(max_nodes_config)
        except (ValueError, TypeError):
            curr_max = 1

        try:
            max_nodes_30d = float(max_nodes_30d)
        except (ValueError, TypeError):
            max_nodes_30d = 0.0
        try:
            peak_cpu_30d = float(peak_cpu_30d)
        except (ValueError, TypeError):
            peak_cpu_30d = 0.0

        # Normalize peak_cpu_30d to ratio [0.0 .. 1.0] and percentage [0.0 .. 100.0]
        if peak_cpu_30d > 1.0:
            cpu_ratio = peak_cpu_30d / 100.0
            cpu_pct = peak_cpu_30d
        elif peak_cpu_30d > 0.0:
            cpu_ratio = peak_cpu_30d
            cpu_pct = peak_cpu_30d * 100.0
        else:
            cpu_ratio = 0.0
            cpu_pct = 0.0

        # Autoscaler Recommendation Rule:
        # Sizing adjustment is only valid when cluster CPU utilization target exceeds 70%.
        # If <= 70%, the previously configured max nodes is the recommended value.
        if cpu_pct <= 70.0:
            return curr_max, f"Optimal (30d Peak CPU {cpu_pct:.1f}% <= 70% threshold; configured {curr_max} max nodes sufficient)"

        peak_nodes_30d = int(max_nodes_30d) if max_nodes_30d > 0 else curr_max
        safe_target_ratio = 0.45 if is_multi_region else 0.65
        safe_target_pct = 45.0 if is_multi_region else 65.0

        # If CPU exceeds 70%, calculate required nodes and apply 1.2X scaling factor
        required_nodes_cpu = math.ceil(peak_nodes_30d * (cpu_ratio / safe_target_ratio))
        recommended_max = max(int(math.ceil(required_nodes_cpu * 1.2)), curr_max)
        reason = f"30d Peak CPU ({cpu_pct:.1f}%) exceeds 70% threshold: 1.2x headroom on {required_nodes_cpu} nodes needed (target: {int(safe_target_pct)}%)"

        return recommended_max, reason

    def inspect_backups(self, project_id, inst_id, token=None):
        """Inspects Cloud Spanner backups for an instance directly via Cloud Asset Inventory."""
        logging.info(f"Querying Cloud Asset Inventory for Spanner backups in {inst_id}...")
        cai_out = self.run_gcloud([
            "asset", "search-all-resources",
            f"--scope=projects/{project_id}",
            "--asset-types=spanner.googleapis.com/Backup",
            f"--query=parentFullResourceName:*instances/{inst_id}*",
            "--format=json"
        ], project_id, token)
        if not cai_out:
            cai_out = self.run_gcloud([
                "asset", "search-all-resources",
                f"--scope=projects/{project_id}",
                "--asset-types=spanner.googleapis.com/Backup",
                "--format=json"
            ], project_id, token)
        
        if cai_out and "PERMISSION_DENIED" not in cai_out:
            try:
                assets = json.loads(cai_out)
                if isinstance(assets, list):
                    matching = []
                    for a in assets:
                        parent = a.get("parentFullResourceName", "")
                        name = a.get("name", "")
                        db = a.get("additionalAttributes", {}).get("database", "")
                        if f"/instances/{inst_id}" in parent or f"/instances/{inst_id}/backups/" in name or f"/instances/{inst_id}/databases/" in db:
                            matching.append(a)
                    if len(matching) > 0:
                        logging.info(f"🎉 Discovered {len(matching)} backups in {inst_id} via Cloud Asset Inventory.")
                        if len(matching) == 1:
                            b_name = matching[0].get("displayName") or matching[0].get("name", "").split("/")[-1]
                            return f"✅ Configured (1 backup: `{b_name}`)"
                        else:
                            return f"✅ Configured ({len(matching)} backups)"
                    else:
                        return "⚠️ None Detected (0 backups found)"
            except Exception as e:
                logging.warning(f"Error parsing CAI response for backups: {e}")

        return "⚠️ None Detected (0 backups found)"

    def inspect_databases(self, project_id, inst_id, token=None):
        """Inspects all databases in a Spanner instance directly via Cloud Asset Inventory."""
        logging.info(f"Querying Cloud Asset Inventory for Spanner databases in {inst_id}...")
        cai_out = self.run_gcloud([
            "asset", "search-all-resources",
            f"--scope=projects/{project_id}",
            "--asset-types=spanner.googleapis.com/Database",
            f"--query=parentFullResourceName:*instances/{inst_id}*",
            "--format=json"
        ], project_id, token)
        if not cai_out:
            cai_out = self.run_gcloud([
                "asset", "search-all-resources",
                f"--scope=projects/{project_id}",
                "--asset-types=spanner.googleapis.com/Database",
                "--format=json"
            ], project_id, token)
        
        if cai_out and "PERMISSION_DENIED" not in cai_out:
            try:
                assets = json.loads(cai_out)
                if isinstance(assets, list) and assets:
                    results = []
                    for a in assets:
                        asset_name = a.get("name", "")
                        if f"/instances/{inst_id}/databases/" not in asset_name:
                            continue
                        db_name = asset_name.split("/")[-1]
                        state = a.get("state", "READY")
                        results.append({
                            "database_id": db_name,
                            "state": state,
                            "dialect": "Unknown (Asset Inventory)",
                            "version_retention_period": "Unknown",
                            "optimizer_version": "Default",
                            "optimizer_statistics_package": "Default",
                        })
                    logging.info(f"🎉 Discovered {len(results)} databases in {inst_id} via Cloud Asset Inventory.")
                    return results
            except Exception as e:
                logging.warning(f"Error parsing CAI response for databases: {e}")

        return []



    def inspect_zonal_quota_check(self, project_num, inst_id, max_nodes_30d, max_config_nodes):
        """Checks 30-day cluster node utilization pattern against regional quota and limits."""
        try:
            limit_nodes = max(int(max_config_nodes), 1)
            util_pct = (float(max_nodes_30d) / limit_nodes) * 100.0
            if util_pct > 80.0:
                return f"⚠️ High Regional Capacity Utilization (30d Peak: {max_nodes_30d} nodes, {util_pct:.1f}% of limit)"
            else:
                return f"✅ Within Quota (<80% Peak Utilization: {util_pct:.1f}%)"
        except Exception:
            return "✅ Within Quota"

    def evaluate_single_instance(self, inst, project_id, project_num, token=None):
        """Evaluates an individual Spanner instance."""
        inst_name = inst.get("name", "")
        inst_id = inst_name.split("/")[-1] if "/" in inst_name else inst.get("id", "unknown")
        logging.info(f"🔍 Evaluating Spanner instance: {inst_id}...")

        # Enrich instance with describe if missing detailed compute configuration
        if not inst.get("autoscalingConfig") and not inst.get("nodeCount") and not inst.get("processingUnits"):
            desc_out = self.run_gcloud(["spanner", "instances", "describe", inst_id, "--format=json"], project_id, token)
            if desc_out and "PERMISSION_DENIED" not in desc_out and "not found" not in desc_out:
                try:
                    desc_data = json.loads(desc_out)
                    if isinstance(desc_data, dict):
                        inst.update(desc_data)
                except Exception:
                    pass

        config_name = inst.get("config", "").split("/")[-1]
        is_multi_region = self.is_multi_region_config(config_name)
        topology_type = "Multi-Region / Dual-Region (99.999% SLA)" if is_multi_region else "Regional (99.99% SLA)"
        target_cpu_thresh = 45.0 if is_multi_region else 65.0

        # Databases & Backups
        databases = self.inspect_databases(project_id, inst_id, token)
        backup_status = self.inspect_backups(project_id, inst_id, token)

        # Monarch Telemetry
        bp = self.evaluate_best_practices(project_id, project_num, inst_id, config_name)

        # Autoscaling vs Fixed Capacity
        autoscaling = inst.get("autoscalingConfig", None)
        if autoscaling:
            limits = autoscaling.get("autoscalingLimits", {})
            min_n_raw = limits.get("minNodes")
            max_n_raw = limits.get("maxNodes")
            min_pu_raw = limits.get("minProcessingUnits")
            max_pu_raw = limits.get("maxProcessingUnits")

            if min_n_raw is not None:
                min_nodes_val = int(min_n_raw)
                min_pu_val = min_nodes_val * 1000
            elif min_pu_raw is not None:
                min_pu_val = int(min_pu_raw)
                min_nodes_val = max(min_pu_val // 1000, 1) if min_pu_val >= 1000 else round(min_pu_val / 1000.0, 1)
            else:
                min_nodes_val = 1
                min_pu_val = 1000

            if max_n_raw is not None:
                max_nodes_val = int(max_n_raw)
                max_pu_val = max_nodes_val * 1000
            elif max_pu_raw is not None:
                max_pu_val = int(max_pu_raw)
                max_nodes_val = max(max_pu_val // 1000, 1) if max_pu_val >= 1000 else round(max_pu_val / 1000.0, 1)
            else:
                max_nodes_val = max(min_nodes_val, 1)
                max_pu_val = max_nodes_val * 1000

            targets = autoscaling.get("autoscalingTargets", {})
            hp_target = targets.get("highPriorityCpuUtilizationPercent", "?")
            min_display = f"{min_nodes_val} nodes ({min_pu_val:,} PUs)" if min_pu_val >= 1000 else f"{min_pu_val} PUs"
            max_display = f"{max_nodes_val} nodes ({max_pu_val:,} PUs)" if max_pu_val >= 1000 else f"{max_pu_val} PUs"
            auto_status = f"✅ Autoscaling Enabled (Min: {min_display}, Max: {max_display}, High-Prio CPU Target: {hp_target}%)"
            min_nodes_config = str(min_nodes_val)
            max_nodes_config = str(max_nodes_val)
        else:
            nodes = inst.get("nodeCount")
            pus = inst.get("processingUnits")
            if nodes is not None and int(nodes) > 0:
                n_val = int(nodes)
                pu_val = n_val * 1000
                cap_str = f"{n_val} nodes ({pu_val:,} PUs)"
                min_nodes_config = str(n_val)
                max_nodes_config = str(n_val)
            elif pus is not None and int(pus) > 0:
                pu_val = int(pus)
                if pu_val >= 1000:
                    n_val = pu_val // 1000
                    cap_str = f"{n_val} nodes ({pu_val:,} PUs)"
                    min_nodes_config = str(n_val)
                    max_nodes_config = str(n_val)
                else:
                    cap_str = f"{pu_val} PUs ({pu_val/1000.0} nodes)"
                    min_nodes_config = f"{pu_val} PUs"
                    max_nodes_config = f"{pu_val} PUs"
            else:
                monarch_nodes = float(bp.get("max_nodes_30d", 0.0) or 0.0)
                if monarch_nodes > 0:
                    n_val = int(monarch_nodes)
                    cap_str = f"{n_val} nodes (Observed via Monarch)"
                    min_nodes_config = str(n_val)
                    max_nodes_config = str(n_val)
                else:
                    cap_str = "1 node"
                    min_nodes_config = "1"
                    max_nodes_config = "1"
            auto_status = f"⚠️ Fixed Capacity ({cap_str}, Autoscaling Disabled)"

        zonal_quota_check = self.inspect_zonal_quota_check(project_num, inst_id, bp.get("max_nodes_30d", 0.0), max_nodes_config)

        rec_max_nodes, rec_max_reason = self.calculate_30d_node_recommendation(
            min_nodes_config, max_nodes_config,
            bp.get("max_total_cpu_30d", 0.0),
            bp.get("max_nodes_30d", 0.0),
            is_multi_region=is_multi_region,
            project_num=project_num,
            inst_id=inst_id
        )

        state = inst.get("state", "READY")
        state_ok = "✅ READY" if state == "READY" else f"❌ {state}"

        cpu_30d_val = bp.get("max_total_cpu_30d", 0.0)
        try:
            cpu_30d_float = float(cpu_30d_val)
        except (ValueError, TypeError):
            cpu_30d_float = 0.0
        cpu_30d_pct = cpu_30d_float if cpu_30d_float > 1.0 else (cpu_30d_float * 100.0)

        overall = "Ready"
        if state != "READY":
            overall = "Not Ready"
        elif (not autoscaling or "⚠️" in zonal_quota_check or "⚠️" in backup_status or cpu_30d_pct > target_cpu_thresh):
            overall = "Ready with Warnings"

        db_names = [d["database_id"] for d in databases] if databases else ["(No databases found)"]

        return {
            "project_id": project_id,
            "instance_id": inst_id,
            "config_name": config_name,
            "topology_type": topology_type,
            "is_multi_region": is_multi_region,
            "state": state_ok,
            "min_nodes_config": min_nodes_config,
            "max_nodes_config": max_nodes_config,
            "recommended_max_nodes_30d": rec_max_nodes,
            "recommended_max_nodes_reason": rec_max_reason,
            "autoscaling": auto_status,
            "databases": databases,
            "database_names": db_names,
            "backups": backup_status,
            "zonal_quota_check": zonal_quota_check,
            "overall": overall,
            "project_num": project_num,
            "best_practices": bp
        }

    def evaluate_project(self, project_id, target_instance=None, token=None):
        """Discovers and evaluates all Spanner instances and databases in the project."""
        target_token = token or self.get_valid_project_token(project_id)

        actual_project_id, project_num = self.resolve_project_identifier(project_id, token=target_token)
        logging.info(f"Evaluating project ID: {actual_project_id} (Project Number: {project_num})")

        instances = self.discover_instances(actual_project_id, target_instance=target_instance, token=target_token)

        if not instances:
            logging.warning(f"No accessible Cloud Spanner instances found in project {actual_project_id} or permission denied.")
            return []

        results = []
        try:
            filtered_instances = [
                inst for inst in instances 
                if not target_instance or (inst.get("name", "").split("/")[-1] == target_instance)
            ]

            if len(filtered_instances) == 1:
                res = self.evaluate_single_instance(filtered_instances[0], actual_project_id, project_num, token)
                results.append(res)
            else:
                max_workers = min(len(filtered_instances), 8)
                with ThreadPoolExecutor(max_workers=max_workers) as executor:
                    future_to_inst = {
                        executor.submit(self.evaluate_single_instance, inst, actual_project_id, project_num, token): inst 
                        for inst in filtered_instances
                    }
                    for future in as_completed(future_to_inst):
                        try:
                            res = future.result()
                            if res:
                                results.append(res)
                        except Exception as e:
                            logging.error(f"Error evaluating instance: {e}")

        except Exception as e:
            logging.error(f"Error evaluating Spanner instances for project {actual_project_id}: {e}")

        results.sort(key=lambda x: x.get("instance_id", ""))
        return results

    def compile_markdown_matrix(self, results):
        if not results:
            return "_No Cloud Spanner instances evaluated._"

        def format_30d_cpu(r):
            cpu_30d = r.get("best_practices", {}).get("max_total_cpu_30d", 0.0)
            try:
                cpu_30d = float(cpu_30d)
            except (ValueError, TypeError):
                cpu_30d = 0.0
            
            is_mr = r.get("is_multi_region", False)
            target = 45.0 if is_mr else 65.0
            cpu_pct = cpu_30d if cpu_30d > 1.0 else (cpu_30d * 100.0)
            if cpu_pct > target:
                return f"⚠️ {cpu_pct:.1f}% (High: >{int(target)}% target)"
            elif cpu_pct > 0.0:
                return f"✅ {cpu_pct:.1f}% (<{int(target)}% target)"
            else:
                return "N/A"

        def format_databases(r):
            dbs = r.get("databases", [])
            if not dbs:
                return "_0 Databases_"
            names = [f"`{d['database_id']}` ({d['dialect']})" for d in dbs]
            return "<br>".join(names)

        def format_7d_qps(r):
            qps_7d = r.get("best_practices", {}).get("peak_qps_7d", 0.0)
            try:
                qps_7d = float(qps_7d)
            except (ValueError, TypeError):
                qps_7d = 0.0
            if qps_7d > 0.0:
                return f"**{qps_7d:,.1f} QPS**"
            else:
                return "N/A"

        rows_def = [
            ("Project ID", lambda r: f"`{r['project_id']}`"),
            ("Instance ID", lambda r: f"`{r['instance_id']}`"),
            ("Instance Config / Topology", lambda r: f"`{r['config_name']}`<br>{r['topology_type']}"),
            ("Min Node Config", lambda r: f"`{r.get('min_nodes_config', 'N/A')}` nodes" if str(r.get('min_nodes_config', '')).isdigit() else f"`{r.get('min_nodes_config', 'N/A')}`"),
            ("Max Node Config", lambda r: f"`{r.get('max_nodes_config', 'N/A')}` nodes" if str(r.get('max_nodes_config', '')).isdigit() else f"`{r.get('max_nodes_config', 'N/A')}`"),
            ("30d Recommended Max Nodes", lambda r: f"**`{r.get('recommended_max_nodes_30d', 'N/A')}` nodes**"),
            ("30d Peak Total CPU Usage", format_30d_cpu),
            ("Autoscaling Configuration", lambda r: r['autoscaling']),
            ("Databases & Dialects", format_databases),
            ("Managed Backups", lambda r: r.get('backups', 'N/A')),
            ("7d Peak QPS", format_7d_qps),
            ("Overall Instance Readiness", lambda r: f"**{r['overall']}**")
        ]
        
        first_label, first_func = rows_def[0]
        headers = [f"**{first_label}**"] + [first_func(r) for r in results]
        dividers = [":---"] * len(headers)
        
        lines = [
            "| " + " | ".join(headers) + " |",
            "| " + " | ".join(dividers) + " |"
        ]
        for label, val_func in rows_def[1:]:
            row_vals = [f"**{label}**"] + [val_func(r) for r in results]
            lines.append("| " + " | ".join(row_vals) + " |")
            
        return "\n".join(lines)

    def compile_internal_links(self, results):
        blocks = []
        for r in results:
            proj_id = r["project_id"]
            inst_id = r["instance_id"]
            cfg = r["config_name"]
            proj_num = r.get("project_num", "N/A")

            sizing = "\n  **⚙️ Compute Capacity & 30-Day Sizing:**"
            sizing += f"\n  - **Min Node Count Config**: `{r.get('min_nodes_config', 'N/A')}` nodes"
            sizing += f"\n  - **Max Node Count Config**: `{r.get('max_nodes_config', 'N/A')}` nodes"
            sizing += f"\n  - **Recommended Max Nodes (30-Day Evaluation)**: **`{r.get('recommended_max_nodes_30d', 'N/A')}` nodes** ({r.get('recommended_max_nodes_reason', 'Optimal')})"

            automon = f"http://monitoring/dashboard/storage%2Fspanner%2Fcustomer_console?scope=cloud_project_number={proj_num}&instance={inst_id}"
            console_overview = f"https://console.cloud.google.com/spanner/instances/{inst_id}/overview?project={proj_id}"

            db_links = []
            for db in r.get("databases", []):
                db_id = db["database_id"]
                keyvis = f"https://console.cloud.google.com/spanner/instances/{inst_id}/databases/{db_id}/key-visualizer?project={proj_id}"
                query_insights = f"https://console.cloud.google.com/spanner/instances/{inst_id}/databases/{db_id}/query-insights?project={proj_id}"
                db_links.append(f"  - **Database `{db_id}`**: [Key Visualizer]({keyvis}) | [Query Insights]({query_insights})")

            db_section = "\n" + "\n".join(db_links) if db_links else ""

            blocks.append(
                f"### Cloud Spanner Instance: `{inst_id}` (`{cfg}`)\n"
                f"- [Cloud Spanner Overview Dashboard]({automon})\n"
                f"- [Cloud Console Instance Overview]({console_overview}){sizing}{db_section}"
            )
        return "\n\n".join(blocks)

    def generate_recommendations(self, results):
        rec = []
        for r in results:
            inst_label = f"Instance `{r['instance_id']}` ({r['config_name']})"
            is_mr = r.get("is_multi_region", False)
            target_cpu_thresh = 45.0 if is_mr else 65.0

            if "⚠️" in r["autoscaling"]:
                rec.append(f"- **{inst_label}**: **Autoscaling Warning**: Instance uses fixed node capacity. Configure the Cloud Spanner Autoscaler (`autoscalingConfig`) with appropriate min/max limits and target CPU/storage metrics to handle event traffic spikes automatically.")
            if "⚠️" in r.get("backups", ""):
                rec.append(f"- **{inst_label}**: **Data Durability Warning**: No recent backups detected. Configure automated backup schedules or regular on-demand backups prior to peak event traffic.")
            if "⚠️" in r.get("zonal_quota_check", ""):
                rec.append(f"- **{inst_label}**: **Regional Quota & Peak Sizing Warning**: 30-day peak node count exceeded 80% of configured maximum nodes. Verify that your Google Cloud regional node quota allows sufficient upscaling headroom.")

            try:
                curr_max = int(r.get("max_nodes_config", 0))
                rec_max = int(r.get("recommended_max_nodes_30d", 0))
                if curr_max > 0 and rec_max > curr_max:
                    rec.append(f"- **{inst_label}**: **Max Node Capacity Warning**: Configured maximum node count (`{curr_max}` nodes) is lower than the recommended maximum (`{rec_max}` nodes) based on 30-day telemetry ({r.get('recommended_max_nodes_reason')}). Increase `maxNodes` to at least **{rec_max} nodes**.")
            except (ValueError, TypeError):
                pass

            bp = r.get("best_practices", {})
            cpu_30d = bp.get("max_total_cpu_30d", 0.0)
            cpu_7d = bp.get("max_total_cpu_7d", 0.0)
            high_prio_cpu = bp.get("max_high_prio_cpu_7d", 0.0)
            storage_peak = bp.get("max_storage_utilization", 0.0)
            api_errors = bp.get("api_error_count_7d", 0.0)
            api_aborts = bp.get("api_aborted_count_7d", 0.0)

            try:
                cpu_30d_f = float(cpu_30d)
            except (ValueError, TypeError):
                cpu_30d_f = 0.0
            cpu_30d_pct = cpu_30d_f if cpu_30d_f > 1.0 else (cpu_30d_f * 100.0)

            try:
                high_prio_f = float(high_prio_cpu)
            except (ValueError, TypeError):
                high_prio_f = 0.0
            high_prio_pct = high_prio_f if high_prio_f > 1.0 else (high_prio_f * 100.0)

            try:
                storage_f = float(storage_peak)
            except (ValueError, TypeError):
                storage_f = 0.0
            storage_pct = storage_f if storage_f > 1.0 else (storage_f * 100.0)

            if cpu_30d_pct >= target_cpu_thresh:
                rec.append(f"- **{inst_label}**: **High 30-Day Total CPU Load**: 30-day peak CPU reached **{cpu_30d_pct:.1f}%** (>= {int(target_cpu_thresh)}% target for {'Multi-Region' if is_mr else 'Regional'}). Pre-scale nodes or increase autoscaling max limits prior to event.")
            if high_prio_pct >= target_cpu_thresh:
                rec.append(f"- **{inst_label}**: **High Priority CPU Spike**: High-priority CPU reached **{high_prio_pct:.1f}%**. Review query patterns and consider scaling instance capacity.")
            if storage_pct >= 70.0:
                rec.append(f"- **{inst_label}**: **Storage Utilization Warning**: Storage utilization reached **{storage_pct:.1f}%** (>= 70% limit). Add node capacity or purge obsolete data to prevent split bottlenecks.")
            if isinstance(api_errors, (int, float)) and api_errors > 0:
                rec.append(f"- **{inst_label}**: **CRITICAL (API Server Errors)**: **{int(api_errors)}** non-OK API errors logged over the past 7 days (DEADLINE_EXCEEDED / UNAVAILABLE / INTERNAL). Review application logs and timeout configurations.")
            if isinstance(api_aborts, (int, float)) and api_aborts > 50:
                rec.append(f"- **{inst_label}**: **High Transaction Abort Rate**: **{int(api_aborts)}** transaction aborts logged over 7 days. Inspect Lock Insights and Query Insights for transaction lock contention.")

        if not rec:
            rec.append("- ✅ **All evaluated Cloud Spanner instances and databases meet full Event Readiness requirements.** Continue standard dashboard monitoring during the production event.")
        return "\n".join(rec)

    def generate_full_report(self, project_id, results, internal_only=False):
        base_dir = os.path.dirname(os.path.abspath(__file__))
        template_file = os.path.join(base_dir, "report_template.md")
        with open(template_file, "r") as f:
            template = f.read()

        actual_project_id = results[0].get("project_id", project_id) if results else project_id
        proj_num = results[0].get("project_num", "N/A") if results else "N/A"
        matrix = self.compile_markdown_matrix(results)
        recs = self.generate_recommendations(results)

        overall = "✅ READY"
        warning_banner = ""

        if self.auth_error:
            overall = "❌ AUTHENTICATION REQUIRED"
            warning_banner = f"> [!CAUTION]\n> **CRITICAL - GCLOUD AUTHENTICATION MISSING**: Cloudtop environment lacks authenticated credentials. Run `{self.display_gcloud_bin} auth login --no-launch-browser`."
            recs = f"- ❌ **Execute `{self.display_gcloud_bin} auth login --no-launch-browser`** to enable API queries."
        else:
            for r in results:
                if r["overall"] == "Not Ready":
                    overall = "❌ NOT READY"
                    warning_banner = "> [!CAUTION]\n> **CRITICAL**: Critical infrastructure checks failed. Immediate corrective action required."
                    break
                elif r["overall"] == "Ready with Warnings":
                    overall = "⚠️ READY WITH WARNINGS"
                    warning_banner = "> [!WARNING]\n> Infrastructure is operational but fails to meet all production best-practice guidelines. Review recommendations."

        if not internal_only:
            warning_banner = "> [!IMPORTANT]\n> **Customer Sharing Disclaimer**: This report was AI-generated by the Jetski Cloud Spanner Event Readiness Checker. Please review recommendations carefully before sharing with the customer.\n\n" + warning_banner
            template = template.replace("{{INTERNAL_REPORT_SECTION}}", "")
            template = re.sub(r'## 4\. TAM & Account Readiness Checklist.*?$', '', template, flags=re.DOTALL)
        else:
            template = template.replace("{{INTERNAL_REPORT_SECTION}}", "---")
            links = self.compile_internal_links(results)
            template = template.replace("{{INTERNAL_LINKS}}", links)
            template = template.replace("{{PROJECT_NUMBER}}", proj_num)
            eval_insts = ", ".join(list(set([r["instance_id"] for r in results]))) if results else "N/A"
            template = template.replace("{{EVALUATED_INSTANCES}}", eval_insts)

        template = re.sub(r'\{\{\s*PROJECT_ID\s*\}\}', str(actual_project_id), template)
        template = re.sub(r'\{\{\s*OVERALL_STATUS\s*\}\}', str(overall), template)
        template = re.sub(r'\{\{\s*TIMESTAMP\s*\}\}', datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), template)
        template = re.sub(r'\{\{\s*JUSTIFICATION\s*\}\}', str(self.format_data_access_reason(self.justification)) if self.justification else "N/A", template)
        template = re.sub(r'\{\{\s*OVERALL_WARNING_BANNER\s*\}\}', str(warning_banner), template)
        template = re.sub(r'\{\{\s*(?:MATRIX_TABLE|MATRIX_ROWS)\s*\}\}', str(matrix), template)
        template = re.sub(r'\{\{\s*RECOMMENDATIONS\s*\}\}', str(recs), template)

        return template

    generate_report = generate_full_report

    def publish_dual_tab_gdoc(self, project_id, internal_md, external_md):
        """Publishes atomic Google Doc via gdocs CLI."""
        if not os.path.exists(GDOCS_CLI_PATH):
            raise RuntimeError(f"gdocs CLI not found at {GDOCS_CLI_PATH}. Markdown fallback is disabled.")

        report_file = f"/tmp/spanner_readiness_report_{project_id}.md"
        with open(report_file, "w") as f:
            f.write(internal_md)

        try:
            logging.info(f"Uploading Native Google Doc report deliverable for {project_id}...")
            cmd = [GDOCS_CLI_PATH, "mutate", "import-md", report_file, f"--title=Cloud Spanner Event Readiness Report - {project_id}"]
            res = subprocess.run(cmd, capture_output=True, text=True, check=True, timeout=180)
            
            doc_id_match = re.search(r'(?:ID:\s*|document/d/|Link:\s*https://docs\.google\.com/document/d/)([a-zA-Z0-9_-]{25,})', res.stdout + res.stderr)
            if not doc_id_match:
                raise RuntimeError(f"Failed to parse document ID from GDocs API response: {res.stdout}")
                
            doc_id = doc_id_match.group(1)
            final_url = f"https://docs.google.com/document/d/{doc_id}/edit"
            logging.info(f"🦅 Successfully published Google Doc deliverable for {project_id}: {final_url}")
            return final_url
        except Exception as e:
            raise RuntimeError(f"Failed to publish Google Doc: {e}")


_jobs = {}
_jobs_lock = threading.Lock()


def _run_evaluation_job(job_id, project_ids, justification, instance_id, token):
    try:
        web_log_handler.clear()
        logging.info(f"Starting Web Evaluation for projects: {project_ids}")
        checker = SpannerReadinessChecker(justification=justification, token=token)
        docs_out = []

        for pid in project_ids:
            results = checker.evaluate_project(pid, target_instance=instance_id, token=token)
            actual_pid = results[0]["project_id"] if results else pid
            internal_md = checker.generate_full_report(actual_pid, results, internal_only=True)
            external_md = checker.generate_full_report(actual_pid, results, internal_only=False)
            
            doc_url = checker.publish_dual_tab_gdoc(actual_pid, internal_md, external_md)
            if not doc_url or not doc_url.startswith("http"):
                raise RuntimeError("Failed to generate Google Document. Markdown fallback is strictly disabled.")

            docs_out.append({
                "project": actual_pid,
                "url": doc_url,
                "is_gdoc": True,
                "preview": "✅ Google Document generated successfully. Markdown output is disabled."
            })

        with _jobs_lock:
            if job_id in _jobs:
                _jobs[job_id]["status"] = "SUCCESS"
                _jobs[job_id]["docs"] = docs_out
                _jobs[job_id]["end_time"] = time.time()
        logging.info(f"🎉 Evaluation Job completed successfully for {project_ids}!")
    except Exception as e:
        logging.exception(f"Web evaluation error for job {job_id}: {e}")
        with _jobs_lock:
            if job_id in _jobs:
                _jobs[job_id]["status"] = "FAILED"
                _jobs[job_id]["error"] = str(e)
                _jobs[job_id]["end_time"] = time.time()


class ReadinessHTTPServer(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        url_parsed = urlparse(self.path)
        if url_parsed.path == "/api/logs":
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            logs_str = web_log_handler.get_logs()
            response_json = json.dumps({"logs": logs_str})
            self.wfile.write(response_json.encode("utf-8"))
            return

        if url_parsed.path in ["/api/status", "/api/job_status", "/api/evaluate/status"]:
            params = parse_qs(url_parsed.query)
            job_id = params.get("job_id", [""])[0]
            with _jobs_lock:
                job_data = _jobs.get(job_id, {"status": "NOT_FOUND", "error": "Job not found"})
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(json.dumps(job_data).encode("utf-8"))
            return

        # the /report markdown endpoint is entirely removed as requested.

        if url_parsed.path in ["/", "/index.html"]:
            self.send_response(200)
            self.send_header("Content-type", "text/html; charset=utf-8")
            self.end_headers()

            html_template = """
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <title>Cloud Spanner Event Readiness Dashboard</title>
                <style>
                    body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f5f7fa; color: #333; margin: 0; padding: 20px; }
                    .container { max-width: 1100px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
                    h1 { color: #1a73e8; border-bottom: 2px solid #1a73e8; padding-bottom: 10px; margin-top: 0; }
                    label { font-weight: bold; display: block; margin-top: 15px; margin-bottom: 5px; }
                    input[type="text"] { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; font-size: 16px; }
                    .help { font-size: 12px; color: #666; margin-top: 4px; font-style: italic; }
                    .help-warning { font-size: 13px; color: #d93025; font-weight: bold; margin-top: 5px; }
                    button { background-color: #1a73e8; color: white; border: none; padding: 12px 24px; font-size: 16px; border-radius: 4px; cursor: pointer; margin-top: 25px; width: 100%; transition: background 0.3s; }
                    button:hover { background-color: #1557b0; }
                    .result-box { margin-top: 30px; padding: 25px; background-color: #e6f4ea; border: 1px solid #ceead6; border-radius: 8px; text-align: center; display: none; }
                    .result-box h3 { color: #1e8e3e; margin-top: 0; }
                    .gdoc-card { display: inline-block; background: white; padding: 20px; border-radius: 8px; border: 1px solid #dadce0; box-shadow: 0 2px 4px rgba(0,0,0,0.05); margin-top: 15px; margin-bottom: 10px; width: 90%; }
                    .btn-gdoc { display: inline-block; background-color: #1a73e8; color: white; text-decoration: none; padding: 12px 28px; border-radius: 4px; font-weight: bold; font-size: 15px; margin-top: 15px; box-shadow: 0 2px 4px rgba(0,0,0,0.2); }
                    .btn-gdoc:hover { background-color: #1557b0; }
                    .report-preview { text-align: left; background: #fff; padding: 20px; border: 1px solid #ddd; border-radius: 4px; margin-top: 20px; max-height: 500px; overflow-y: scroll; font-family: monospace; white-space: pre-wrap; font-size: 13px; line-height: 1.4; }
                    .log-box { background-color: #202124; color: #34a853; font-family: 'Consolas', 'Courier New', monospace; padding: 15px; height: 200px; overflow-y: scroll; border-radius: 4px; margin-top: 25px; text-align: left; display: none; font-size: 13px; line-height: 1.5; }
                    .instructions { background-color: #fff9e6; border: 1px solid #ffe0b2; padding: 15px; border-radius: 4px; margin-top: 20px; font-size: 14px; }
                </style>
            </head>
            <body>
                <div class="container">
                    <h1>🛡️ Cloud Spanner Event Readiness Dashboard</h1>
                    <p>Enter the Customer Project ID or Numeric Project Number. Performs comprehensive 14-dimension verification across instances, databases, backups, capacity limits, and 7d/30d Monarch telemetry.</p>
                    
                    <form action="/api/evaluate" method="POST">
                        <label for="project_id">Customer Project ID or Project Number:</label>
                        <input type="text" id="project_id" name="project_id" required placeholder="e.g. uat-gcp or 879940934289 or fc-futc-prd-gcp">
                        
                        <label for="justification">Data Access Justification (Buganizer Bug ID OR Vector Case Number):</label>
                        <input type="text" id="justification" name="justification" required placeholder="e.g. 541322397 or vector/51234567 or b/541322397">
                        <div class="help-warning">⚠️ Mandatory: Ensure this Justification Bug ID (b/...) or Vector Case Number (vector/...) is assigned to you.</div>
                        
                        <label for="instance_id">Target Instance ID (Optional):</label>
                        <input type="text" id="instance_id" name="instance_id" placeholder="e.g. backup or test (Leave blank to evaluate all instances)">

                        <label for="token">Google Admin Project Inspection IAM Token (Optional):</label>
                        <input type="text" id="token" name="token" placeholder="iam-token-abcdef... (Optional override)">
                        
                        <button type="submit">🛡️ Execute Spanner Readiness Check Evaluation</button>
                    </form>
                    
                    <div id="log-box" class="log-box"></div>
                    
                    <div id="results" class="result-box">
                        <h3>🎉 Evaluation Report Complete!</h3>
                        <div id="gdoc-container">
                            <div class="gdoc-card">
                                <div style="font-size: 40px; margin-bottom: 10px;">📄</div>
                                <strong id="report-title">Cloud Spanner Readiness Report</strong>
                                <div style="font-size: 13px; color: #666; margin-top: 5px;">Report deliverable generated and verified.</div>
                                <a id="report-link" class="btn-gdoc" href="" target="_blank">📄 View Formatted Report</a>
                                <div id="report-preview" class="report-preview"></div>
                            </div>
                        </div>
                        <p id="error-fallback" style="display:none; color: #d93025; font-weight: bold; margin-top: 20px;"></p>
                    </div>
                </div>
                <script>
                    const form = document.querySelector('form');
                    const resultsBox = document.getElementById('results');
                    const logBox = document.getElementById('log-box');
                    const gdocContainer = document.getElementById('gdoc-container');
                    const linkNode = document.getElementById('report-link');
                    const previewNode = document.getElementById('report-preview');
                    const errorFallback = document.getElementById('error-fallback');
                    let logInterval = null;
                    let statusInterval = null;
                    
                    function fetchLogs() {
                        fetch('/api/logs')
                            .then(res => res.json())
                            .then(data => {
                                if (data.logs) {
                                    logBox.innerText = data.logs;
                                    logBox.scrollTop = logBox.scrollHeight;
                                }
                            })
                            .catch(err => console.error("Log fetch error: ", err));
                    }
                    
                    form.addEventListener('submit', async (e) => {
                        e.preventDefault();
                        const formData = new FormData(form);
                        const data = {};
                        formData.forEach((value, key) => data[key] = value);
                        
                        const btn = document.querySelector('button');
                        btn.innerText = '⏳ Executing Spanner Verification Matrix...';
                        btn.disabled = true;
                        
                        logBox.style.display = 'block';
                        logBox.innerText = "Initializing Cloud Spanner evaluation...";
                        resultsBox.style.display = 'none';
                        gdocContainer.style.display = 'none';
                        errorFallback.style.display = 'none';
                        
                        if (logInterval) clearInterval(logInterval);
                        if (statusInterval) clearInterval(statusInterval);
                        logInterval = setInterval(fetchLogs, 1000);
                        
                        try {
                            const response = await fetch('/api/evaluate', {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify(data)
                            });
                            
                            const contentType = response.headers.get("content-type");
                            let initResult;
                            if (contentType && contentType.includes("application/json")) {
                                initResult = await response.json();
                            } else {
                                const text = await response.text();
                                throw new Error(text || ("HTTP " + response.status));
                            }

                            if (!initResult.success || !initResult.job_id) {
                                throw new Error(initResult.error || "Failed to initialize evaluation job.");
                            }

                            const jobId = initResult.job_id;

                            // Non-blocking status polling to prevent ÜberProxy timeouts
                            const pollStatus = async () => {
                                try {
                                    const statusRes = await fetch('/api/status?job_id=' + encodeURIComponent(jobId));
                                    const job = await statusRes.json();
                                    
                                    if (job.status === 'SUCCESS') {
                                        clearInterval(logInterval);
                                        clearInterval(statusInterval);
                                        fetchLogs();
                                        
                                        if (job.docs && job.docs.length > 0) {
                                            resultsBox.style.display = 'block';
                                            gdocContainer.style.display = 'block';
                                            errorFallback.style.display = 'none';
                                            const doc = job.docs[0];
                                            linkNode.href = doc.url;
                                            linkNode.innerText = '📄 Open Google Doc Readiness Report';
                                            linkNode.target = '_blank';
                                            if (doc.preview) {
                                                previewNode.innerText = doc.preview;
                                                previewNode.style.display = 'block';
                                            } else {
                                                previewNode.style.display = 'none';
                                            }
                                        } else {
                                            resultsBox.style.display = 'block';
                                            gdocContainer.style.display = 'none';
                                            errorFallback.style.display = 'block';
                                            errorFallback.innerText = "⚠️ No reports generated.";
                                        }
                                        btn.innerText = '🛡️ Execute Spanner Readiness Check Evaluation';
                                        btn.disabled = false;
                                    } else if (job.status === 'FAILED') {
                                        clearInterval(logInterval);
                                        clearInterval(statusInterval);
                                        fetchLogs();
                                        resultsBox.style.display = 'block';
                                        gdocContainer.style.display = 'none';
                                        errorFallback.style.display = 'block';
                                        errorFallback.innerText = "❌ " + (job.error || "Evaluation failed. Check terminal logs.");
                                        btn.innerText = '🛡️ Execute Spanner Readiness Check Evaluation';
                                        btn.disabled = false;
                                    }
                                } catch (pollErr) {
                                    console.error("Status polling error:", pollErr);
                                }
                            };

                            statusInterval = setInterval(pollStatus, 1500);

                        } catch (err) {
                            if (logInterval) clearInterval(logInterval);
                            if (statusInterval) clearInterval(statusInterval);
                            resultsBox.style.display = 'block';
                            gdocContainer.style.display = 'none';
                            errorFallback.style.display = 'block';
                            errorFallback.innerText = "❌ Request Failed: " + err;
                            btn.innerText = '🛡️ Execute Spanner Readiness Check Evaluation';
                            btn.disabled = false;
                        }
                    });
                </script>
            </body>
            </html>
            """
            self.wfile.write(html_template.encode("utf-8"))
            return

    def do_POST(self):
        url_parsed = urlparse(self.path)
        if url_parsed.path in ["/api/evaluate", "/evaluate", "/api/evaluate/", "/evaluate/"]:
            try:
                content_length = int(self.headers.get("Content-Length", 0))
                post_data = self.rfile.read(content_length).decode("utf-8")
                
                try:
                    data = json.loads(post_data)
                except Exception:
                    data = {}
                    for k, v in parse_qs(post_data).items():
                        data[k] = v[0]

                raw_projects = data.get("project_id", "").split(",")
                project_ids = [p.strip() for p in raw_projects if p.strip()]
                justification = data.get("justification", "").strip()
                instance_id = data.get("instance_id", "").strip() or None
                token = data.get("token", "").strip() or None

                job_id = str(uuid.uuid4())
                with _jobs_lock:
                    _jobs[job_id] = {
                        "job_id": job_id,
                        "status": "RUNNING",
                        "project_ids": project_ids,
                        "docs": [],
                        "error": None,
                        "start_time": time.time()
                    }

                t = threading.Thread(
                    target=_run_evaluation_job,
                    args=(job_id, project_ids, justification, instance_id, token),
                    daemon=True
                )
                t.start()

                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.end_headers()
                self.wfile.write(json.dumps({
                    "success": True,
                    "job_id": job_id,
                    "status": "RUNNING"
                }).encode("utf-8"))
                return
            except Exception as e:
                logging.exception(f"Web evaluation error: {e}")
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.end_headers()
                self.wfile.write(json.dumps({"success": False, "error": str(e), "docs": []}).encode("utf-8"))
                return


class ThreadedHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def start_web_server(port=8080):
    server_address = ("", port)
    httpd = ThreadedHTTPServer(server_address, ReadinessHTTPServer)
    logging.info(f"🌐 Starting Cloud Spanner Event Readiness Web Dashboard on http://localhost:{port}")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        logging.info("Shutting down web server...")
        httpd.server_close()


def main():
    parser = argparse.ArgumentParser(description="Cloud Spanner Event Readiness Checker")
    parser.add_argument("--project", help="Customer Project ID or Project Number")
    parser.add_argument("--instance", help="Specific Spanner Instance ID (Optional)")
    parser.add_argument("--justification", help="Data Access Justification (Buganizer Bug ID e.g. b/541322397 or Vector Case Number e.g. vector/51234567)")
    parser.add_argument("--case", help="Vector Case Number for Data Access Justification (e.g. 51234567 or vector/51234567)")
    parser.add_argument("--bug", help="Buganizer Bug ID for Data Access Justification (e.g. 541322397 or b/541322397)")
    parser.add_argument("--token", help="IAM Inspection Token from Google Admin")
    parser.add_argument("--external-only", action="store_true", help="Generate customer-shareable external report only")
    
    parser.add_argument("--web", action="store_true", help="Start Interactive Web UI Dashboard")
    parser.add_argument("--port", type=int, default=8080, help="Port for Web UI Dashboard (Default: 8080)")

    args = parser.parse_args()

    if args.web:
        start_web_server(args.port)
        return

    if not args.project:
        parser.error("You must provide --project unless using --web mode.")

    justification = args.justification or args.case or args.bug
    checker = SpannerReadinessChecker(justification=justification, token=args.token)
    checker.check_gcert()

    logging.info(f"🔍 Evaluating Cloud Spanner Event Readiness for project: {args.project}...")
    results = checker.evaluate_project(args.project, target_instance=args.instance, token=args.token)

    actual_pid = results[0]["project_id"] if results else args.project
    internal_md = checker.generate_full_report(actual_pid, results, internal_only=True)
    external_md = checker.generate_full_report(actual_pid, results, internal_only=False)

    doc_url = checker.publish_dual_tab_gdoc(actual_pid, internal_md, external_md)
    if doc_url and doc_url.startswith("http"):
        print(f"\n✅ Published Cloud Spanner Readiness Report: {doc_url}")
    else:
        raise RuntimeError(f"Failed to generate Google Document. Markdown fallback is strictly disabled.")


if __name__ == "__main__":
    main()
