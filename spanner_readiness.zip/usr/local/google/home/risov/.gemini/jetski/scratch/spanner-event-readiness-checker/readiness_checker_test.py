#!/usr/bin/env python3
"""
Unit test suite for Cloud Spanner Event Readiness Checker.
Tests evaluation logic, recommendations, markdown compilation, and CLI parsing.
"""

import json
import unittest
from unittest.mock import patch, MagicMock
import readiness_checker

class TestSpannerReadinessChecker(unittest.TestCase):
    def setUp(self):
        self.checker = readiness_checker.SpannerReadinessChecker(
            justification="541322397",
            token="test-iam-token"
        )

    def test_is_multi_region_config(self):
        self.assertFalse(self.checker.is_multi_region_config("regional-us-central1"))
        self.assertFalse(self.checker.is_multi_region_config("projects/p/instanceConfigs/regional-europe-west1"))
        self.assertTrue(self.checker.is_multi_region_config("nam3"))
        self.assertTrue(self.checker.is_multi_region_config("nam6"))
        self.assertTrue(self.checker.is_multi_region_config("eur3"))
        self.assertTrue(self.checker.is_multi_region_config("nam-eur-asia1"))

    @patch.object(readiness_checker.SpannerReadinessChecker, "run_gcloud")
    def test_inspect_databases(self, mock_gcloud):
        mock_gcloud.return_value = json.dumps([
            {
                "name": "//spanner.googleapis.com/projects/test-proj/instances/test-inst/databases/ecommerce-db",
                "state": "READY",
                "parentFullResourceName": "//spanner.googleapis.com/projects/test-proj/instances/test-inst"
            },
            {
                "name": "//spanner.googleapis.com/projects/test-proj/instances/test-inst/databases/analytics-db",
                "state": "READY",
                "parentFullResourceName": "//spanner.googleapis.com/projects/test-proj/instances/test-inst"
            }
        ])
        dbs = self.checker.inspect_databases("test-proj", "test-inst")
        self.assertEqual(len(dbs), 2)
        self.assertEqual(dbs[0]["database_id"], "ecommerce-db")
        self.assertEqual(dbs[1]["database_id"], "analytics-db")

    @patch.object(readiness_checker.SpannerReadinessChecker, "run_gcloud")
    def test_inspect_backups_success(self, mock_gcloud):
        mock_gcloud.return_value = json.dumps([
            {
                "name": "//spanner.googleapis.com/projects/test-proj/instances/test-inst/backups/daily-backup-1",
                "displayName": "daily-backup-1",
                "parentFullResourceName": "//spanner.googleapis.com/projects/test-proj/instances/test-inst"
            },
            {
                "name": "//spanner.googleapis.com/projects/test-proj/instances/test-inst/backups/daily-backup-2",
                "displayName": "daily-backup-2",
                "parentFullResourceName": "//spanner.googleapis.com/projects/test-proj/instances/test-inst"
            }
        ])
        res = self.checker.inspect_backups("test-proj", "test-inst")
        self.assertIn("✅ Configured (2 backups)", res)

    @patch.object(readiness_checker.SpannerReadinessChecker, "run_gcloud")
    def test_inspect_backups_single(self, mock_gcloud):
        mock_gcloud.return_value = json.dumps([
            {
                "name": "//spanner.googleapis.com/projects/test-proj/instances/test-inst/backups/cai-backup",
                "displayName": "cai-backup",
                "parentFullResourceName": "//spanner.googleapis.com/projects/test-proj/instances/test-inst"
            }
        ])
        res = self.checker.inspect_backups("test-proj", "test-inst")
        self.assertIn("✅ Configured (1 backup: `cai-backup`)", res)

    @patch.object(readiness_checker.SpannerReadinessChecker, "run_gcloud")
    def test_inspect_backups_none_detected(self, mock_gcloud):
        mock_gcloud.return_value = "[]"
        res = self.checker.inspect_backups("test-proj", "test-inst")
        self.assertIn("⚠️ None Detected", res)

    def test_calculate_30d_node_recommendation_under_threshold(self):
        # Peak CPU <= 70%: recommendation should remain the configured max nodes (curr_max)
        rec_max, reason = self.checker.calculate_30d_node_recommendation("36", "328", 0.627, 328, is_multi_region=False)
        self.assertEqual(rec_max, 328)
        self.assertIn("Optimal", reason)
        self.assertIn("<= 70% threshold", reason)

    def test_calculate_30d_node_recommendation_regional(self):
        # Regional: safe target CPU 65%. 30d peak CPU 78% (> 70%) on 10 nodes
        # required_nodes_cpu = ceil(10 * (0.78 / 0.65)) = 12 nodes * 1.2x = 15 nodes
        rec_max, reason = self.checker.calculate_30d_node_recommendation("3", "10", 0.78, 10, is_multi_region=False)
        self.assertEqual(rec_max, 15)
        self.assertIn("1.2x headroom", reason)

    def test_calculate_30d_node_recommendation_multi_region(self):
        # Multi-region: safe target CPU 45%. 30d peak CPU 75% (> 70%) on 10 nodes
        # required_nodes_cpu = ceil(10 * (0.75 / 0.45)) = 17 nodes * 1.2x = 21 nodes
        rec_max, reason = self.checker.calculate_30d_node_recommendation("3", "10", 0.75, 10, is_multi_region=True)
        self.assertEqual(rec_max, 21)
        self.assertIn("1.2x headroom", reason)

    def test_format_data_access_reason(self):
        self.assertEqual(self.checker.format_data_access_reason("541322397"), "b/541322397")
        self.assertEqual(self.checker.format_data_access_reason("b/541322397"), "b/541322397")
        self.assertEqual(self.checker.format_data_access_reason("51234567"), "vector/51234567")
        self.assertEqual(self.checker.format_data_access_reason("vector/51234567"), "vector/51234567")
        self.assertEqual(self.checker.format_data_access_reason("case/51234567"), "vector/51234567")

    @patch.object(readiness_checker.SpannerReadinessChecker, "run_gcloud")
    @patch.object(readiness_checker.SpannerReadinessChecker, "run_monarch")
    def test_evaluate_project(self, mock_monarch, mock_gcloud):
        mock_monarch.return_value = None
        inst_json = json.dumps([{
            "name": "projects/test-proj/instances/spanner-prod",
            "config": "projects/test-proj/instanceConfigs/regional-us-central1",
            "displayName": "Production Spanner",
            "nodeCount": 3,
            "state": "READY"
        }])
        mock_gcloud.side_effect = [
            json.dumps({"projectId": "test-proj", "projectNumber": "1234567890"}),  # projects describe
            inst_json,                                                             # spanner instances list
            json.dumps([{                                                          # spanner databases list
                "name": "projects/test-proj/instances/spanner-prod/databases/db1",
                "state": "READY",
                "databaseDialect": "GOOGLE_STANDARD_SQL"
            }]),
            "[]"                                                                   # spanner backups list
        ]
        res = self.checker.evaluate_project("test-proj")
        self.assertEqual(len(res), 1)
        self.assertEqual(res[0]["instance_id"], "spanner-prod")
        self.assertEqual(res[0]["config_name"], "regional-us-central1")
        self.assertFalse(res[0]["is_multi_region"])
        self.assertIn("Fixed Capacity (3 nodes (3,000 PUs), Autoscaling Disabled)", res[0]["autoscaling"])
        self.assertEqual(res[0]["min_nodes_config"], "3")
        self.assertEqual(res[0]["max_nodes_config"], "3")
        self.assertEqual(res[0]["overall"], "Ready with Warnings")

    @patch.object(readiness_checker.SpannerReadinessChecker, "run_monarch")
    @patch.object(readiness_checker.SpannerReadinessChecker, "run_gcloud")
    def test_evaluate_instance_autoscaling_processing_units(self, mock_gcloud, mock_monarch):
        mock_monarch.return_value = "0.0"
        inst_dict = {
            "name": "projects/fc-futc-prd-gcp/instances/prd-s5-tradehousei",
            "config": "projects/fc-futc-prd-gcp/instanceConfigs/regional-europe-west2-plus",
            "autoscalingConfig": {
                "autoscalingLimits": {
                    "minProcessingUnits": 36000,
                    "maxProcessingUnits": 328000
                },
                "autoscalingTargets": {
                    "highPriorityCpuUtilizationPercent": 50,
                    "storageUtilizationPercent": 95
                }
            },
            "nodeCount": 36,
            "processingUnits": 36000,
            "state": "READY"
        }
        mock_gcloud.side_effect = [
            "[]",  # CAI databases
            "[]"   # CAI backups
        ]
        res = self.checker.evaluate_single_instance(inst_dict, "fc-futc-prd-gcp", "957928223692")
        self.assertEqual(res["min_nodes_config"], "36")
        self.assertEqual(res["max_nodes_config"], "328")
        self.assertIn("Min: 36 nodes (36,000 PUs)", res["autoscaling"])
        self.assertIn("Max: 328 nodes (328,000 PUs)", res["autoscaling"])
        self.assertIn("High-Prio CPU Target: 50%", res["autoscaling"])
        self.assertEqual(res["recommended_max_nodes_30d"], 328)

    def test_compile_markdown_matrix(self):
        sample_results = [{
            "project_id": "test-proj",
            "instance_id": "spanner-prod",
            "config_name": "regional-us-central1",
            "topology_type": "Regional (99.99% SLA)",
            "is_multi_region": False,
            "autoscaling": "✅ Autoscaling Enabled (Min: 3, Max: 10, High-Prio CPU Target: 65%)",
            "min_nodes_config": "3",
            "max_nodes_config": "10",
            "recommended_max_nodes_30d": 10,
            "overall": "Ready",
            "backups": "✅ Configured (1 backup: `prod-bak`)",
            "databases": [{"database_id": "main-db", "dialect": "GOOGLE_STANDARD_SQL"}],
            "best_practices": {
                "max_total_cpu_30d": 34.5,
                "peak_qps_7d": 1250.0
            }
        }]
        matrix = self.checker.compile_markdown_matrix(sample_results)
        self.assertIn("34.5%", matrix)
        self.assertIn("1,250.0 QPS", matrix)
        self.assertIn("`main-db` (GOOGLE_STANDARD_SQL)", matrix)
        self.assertIn("✅ Configured (1 backup: `prod-bak`)", matrix)

    def test_generate_recommendations_no_warnings(self):
        sample_results = [{
            "project_id": "test-proj",
            "instance_id": "spanner-prod",
            "config_name": "nam3",
            "topology_type": "Multi-Region / Dual-Region (99.999% SLA)",
            "is_multi_region": True,
            "autoscaling": "✅ Autoscaling Enabled (Min: 3, Max: 10, High-Prio CPU Target: 45%)",
            "backups": "✅ Configured (2 backups)",
            "zonal_quota_check": "✅ Within Quota",
            "min_nodes_config": "3",
            "max_nodes_config": "10",
            "recommended_max_nodes_30d": 10,
            "recommended_max_nodes_reason": "Optimal",
            "overall": "Ready",
            "best_practices": {
                "max_total_cpu_30d": 0.35,
                "max_total_cpu_7d": 0.30,
                "max_high_prio_cpu_7d": 0.30,
                "max_storage_utilization": 0.40,
                "api_error_count_7d": 0.0,
                "api_aborted_count_7d": 0.0
            }
        }]
        recs = self.checker.generate_recommendations(sample_results)
        self.assertIn("All evaluated Cloud Spanner instances and databases meet full Event Readiness requirements", recs)

    def test_generate_recommendations_with_warnings(self):
        sample_results = [{
            "project_id": "test-proj",
            "instance_id": "spanner-prod",
            "config_name": "nam3",
            "topology_type": "Multi-Region / Dual-Region (99.999% SLA)",
            "is_multi_region": True,
            "autoscaling": "⚠️ Fixed Capacity (3 nodes, Autoscaling Disabled)",
            "backups": "⚠️ None Detected (0 backups found)",
            "zonal_quota_check": "⚠️ High Regional Capacity Utilization (30d Peak: 9 nodes, 90.0% of limit)",
            "min_nodes_config": "3",
            "max_nodes_config": "5",
            "recommended_max_nodes_30d": 12,
            "recommended_max_nodes_reason": "1.5x headroom on 30d peak",
            "overall": "Ready with Warnings",
            "best_practices": {
                "max_total_cpu_30d": 0.60,
                "max_total_cpu_7d": 0.55,
                "max_high_prio_cpu_7d": 0.50,
                "max_storage_utilization": 0.75,
                "api_error_count_7d": 12.0,
                "api_aborted_count_7d": 80.0
            }
        }]
        recs = self.checker.generate_recommendations(sample_results)
        self.assertIn("Autoscaling Warning", recs)
        self.assertIn("Data Durability Warning", recs)
        self.assertIn("Regional Quota & Peak Sizing Warning", recs)
        self.assertIn("Max Node Capacity Warning", recs)
        self.assertIn("High 30-Day Total CPU Load", recs)
        self.assertIn("Storage Utilization Warning", recs)
        self.assertIn("CRITICAL (API Server Errors)", recs)
        self.assertIn("High Transaction Abort Rate", recs)

    @patch.object(readiness_checker.SpannerReadinessChecker, "resolve_project_number")
    def test_generate_full_report(self, mock_resolve):
        mock_resolve.return_value = "1234567890"
        sample_results = [{
            "project_id": "test-proj",
            "instance_id": "spanner-prod",
            "config_name": "nam3",
            "topology_type": "Multi-Region / Dual-Region (99.999% SLA)",
            "is_multi_region": True,
            "autoscaling": "✅ Autoscaling Enabled (Min: 3, Max: 10, High-Prio CPU Target: 45%)",
            "backups": "✅ Configured (1 backup)",
            "zonal_quota_check": "✅ Within Quota",
            "min_nodes_config": "3",
            "max_nodes_config": "10",
            "recommended_max_nodes_30d": 10,
            "recommended_max_nodes_reason": "Optimal",
            "overall": "Ready",
            "project_num": "1234567890",
            "databases": [{"database_id": "main-db", "dialect": "GOOGLE_STANDARD_SQL"}],
            "best_practices": {
                "max_total_cpu_30d": 0.35,
                "max_total_cpu_7d": 0.30,
                "max_high_prio_cpu_7d": 0.30,
                "max_storage_utilization": 0.40,
                "api_error_count_7d": 0.0,
                "api_aborted_count_7d": 0.0
            }
        }]
        report = self.checker.generate_full_report("test-proj", sample_results, internal_only=True)
        self.assertIn("Cloud Spanner Event Readiness Report - test-proj", report)
        self.assertIn("✅ READY", report)
        self.assertIn("Cloud Spanner Overview Dashboard", report)
        self.assertIn("main-db", report)

    def test_get_valid_project_token_fresh(self):
        # A token created 10 minutes ago (< 59m) should be reused without refresh
        import time
        now = time.time()
        self.checker.project_tokens["test-proj"] = {
            "token": "cached-token-123",
            "timestamp": now - (10 * 60)
        }
        with patch.object(self.checker, "attempt_mcp_token_generation") as mock_gen:
            tok = self.checker.get_valid_project_token("test-proj")
            self.assertEqual(tok, "cached-token-123")
            mock_gen.assert_not_called()

    def test_get_valid_project_token_expired_refresh(self):
        # A token created 59.5 minutes ago (>= 59m) should trigger refresh
        import time
        now = time.time()
        self.checker.project_tokens["test-proj"] = {
            "token": "old-token-abc",
            "timestamp": now - (59.5 * 60)
        }
        with patch.object(self.checker, "attempt_mcp_token_generation") as mock_gen:
            mock_gen.return_value = "new-refreshed-token-xyz"
            tok = self.checker.get_valid_project_token("test-proj")
            self.assertEqual(tok, "new-refreshed-token-xyz")
            mock_gen.assert_called_once_with("test-proj")
            self.assertEqual(self.checker.project_tokens["test-proj"]["token"], "new-refreshed-token-xyz")

    @patch("subprocess.run")
    def test_run_gcloud_token_expiration_retry_after_1_hour(self, mock_run):
        # Token is 65 minutes old (> 1 hour), gcloud fails with 401, reactive retry is performed
        import time
        now = time.time()
        self.checker.project_tokens["test-proj"] = {
            "token": "old-expired-tok",
            "timestamp": now - (65 * 60)
        }
        mock_fail = MagicMock()
        mock_fail.returncode = 1
        mock_fail.stderr = "ERROR: (gcloud.spanner.instances.list) 401 Unauthorized: Access token has expired."
        
        mock_success = MagicMock()
        mock_success.returncode = 0
        mock_success.stdout = json.dumps([{"name": "inst1"}])
        
        mock_run.side_effect = [mock_fail, mock_success]
        
        with patch.object(self.checker, "attempt_mcp_token_generation") as mock_gen:
            mock_gen.return_value = "refreshed-tok"
            out = self.checker.run_gcloud(["spanner", "instances", "list"], "test-proj")
            self.assertIn("inst1", out)
            mock_gen.assert_called_once_with("test-proj")

    @patch("subprocess.run")
    def test_run_gcloud_token_expiration_no_retry_under_1_hour(self, mock_run):
        # Token is only 20 minutes old (< 1 hour), gcloud fails with 401, reactive retry should NOT be triggered
        import time
        now = time.time()
        self.checker.project_tokens["test-proj"] = {
            "token": "fresh-tok",
            "timestamp": now - (20 * 60)
        }
        mock_fail = MagicMock()
        mock_fail.returncode = 1
        mock_fail.stderr = "ERROR: (gcloud.spanner.instances.list) 401 Unauthorized: Permission check failed."
        
        mock_run.return_value = mock_fail
        
        with patch.object(self.checker, "attempt_mcp_token_generation") as mock_gen:
            out = self.checker.run_gcloud(["spanner", "instances", "list"], "test-proj")
            self.assertIsNone(out)
            mock_gen.assert_not_called()

    def test_job_runner_flow(self):
        job_id = "test-job-123"
        with readiness_checker._jobs_lock:
            readiness_checker._jobs[job_id] = {
                "job_id": job_id,
                "status": "RUNNING",
                "docs": [],
                "error": None
            }
        
        with patch.object(readiness_checker.SpannerReadinessChecker, "evaluate_project") as mock_eval, \
             patch.object(readiness_checker.SpannerReadinessChecker, "generate_full_report") as mock_gen, \
             patch.object(readiness_checker.SpannerReadinessChecker, "publish_dual_tab_gdoc") as mock_pub:
            mock_eval.return_value = [{"project_id": "test-p", "instance_id": "i1"}]
            mock_gen.return_value = "# Report"
            mock_pub.return_value = "https://docs.google.com/document/d/doc123/edit"

            readiness_checker._run_evaluation_job(job_id, ["test-p"], "b/541322397", "i1", "token123")
            
            with readiness_checker._jobs_lock:
                job = readiness_checker._jobs[job_id]
                self.assertEqual(job["status"], "SUCCESS")
                self.assertEqual(len(job["docs"]), 1)
                self.assertEqual(job["docs"][0]["url"], "https://docs.google.com/document/d/doc123/edit")

if __name__ == "__main__":
    unittest.main()

