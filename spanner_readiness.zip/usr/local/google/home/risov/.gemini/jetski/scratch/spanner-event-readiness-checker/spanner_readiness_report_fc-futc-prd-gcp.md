<!-- go/g3mark-in-g3doc -->

# Cloud Spanner Event Readiness Report - fc-futc-prd-gcp

**Overall Readiness Status**: ⚠️ READY WITH WARNINGS  
**Target Project**: `fc-futc-prd-gcp`  
**Evaluation Timestamp**: `2026-08-07 03:28:45`  
**Data Access Justification**: `b/541322397`  

> [!WARNING]
> Infrastructure is operational but fails to meet all production best-practice guidelines. Review recommendations.

-----

## 1. Executive Summary & Production Readiness Matrix (Externally Shareable)

This automated evaluation inspects your Cloud Spanner instances, databases, configurations, and 7-day production telemetry against official event readiness best practices.

### Cloud Spanner Instance & Database Evaluation Matrix

| **Project ID** | `fc-futc-prd-gcp` |
| :--- | :--- |
| **Instance ID** | `prd-s5-store` |
| **Instance Config / Topology** | `regional-europe-west2`<br>Regional (99.99% SLA) |
| **Min Node Config** | `1` nodes |
| **Max Node Config** | `1` nodes |
| **30d Recommended Max Nodes** | **`2` nodes** |
| **30d Peak Total CPU Usage** | ✅ 0.0% (<65% target) |
| **Autoscaling Configuration** | ⚠️ Fixed Capacity (1 node, Autoscaling Disabled) |
| **Databases & Dialects** | _0 Databases_ |
| **Managed Backups & Schedules** | ⚠️ 28 Backups Exist, but No Active Backup Schedule Detected on Databases |
| **Client-Side Metrics (CSM) Coverage** | ⚠️ Disabled / 0 QPS (CSM Not Detected on Traffic) |
| **Cold Start Risk (7d Min QPS)** | ⚠️ Cold Start Risk (7d Min QPS: 0.0 - Session Pre-warming Recommended) |
| **30d Regional Quota Check** | ✅ Within Quota (<80% Peak Utilization: 0.0%) |
| **Overall Instance Readiness** | **Ready with Warnings** |

-----

## 2. Best-Practice Recommendations & Corrective Actions

- **Instance `prd-s5-store` (regional-europe-west2)**: **Autoscaling Warning**: Instance uses fixed node capacity. Configure the Cloud Spanner Autoscaler (`autoscalingConfig`) with appropriate min/max limits and target CPU/storage metrics to handle event traffic spikes automatically.
- **Instance `prd-s5-store` (regional-europe-west2)**: **Data Durability Warning**: No automated Backup Schedules or existing backups detected across databases. Configure automated [Backup Schedules](https://cloud.google.com/spanner/docs/backup) for regular automated protection.
- **Instance `prd-s5-store` (regional-europe-west2)**: **Client-Side Metrics (CSM) Warning**: CSM is disabled or not detected on client traffic. Enable CSM on Spanner client libraries for end-to-end latency and session observability.
- **Instance `prd-s5-store` (regional-europe-west2)**: **Cold Start & Session Warmup Warning**: Minimum QPS in the past 7 days dropped below 10 QPS. Pre-warm application client pools by sending synthetic warmup queries (e.g. `SELECT 1`) in batch before event traffic begins.
- **Instance `prd-s5-store` (regional-europe-west2)**: **Max Node Capacity Warning**: Configured maximum node count (`1` nodes) is lower than the recommended maximum (`2` nodes) based on 30-day telemetry (Optimal (Configured headroom sufficient)). Increase `maxNodes` to at least **2 nodes**.

-----

## 3. Customer Event Readiness Checklist Verification

Ensure the following Cloud Spanner architectural best practices are verified before peak traffic events:

-   **Quota & Capacity Planning**:
    -   Check current Cloud Spanner nodes/processing units used per region per project quota (`compute_nodes` / `processing_units`) to ensure sufficient headroom for pre-scaling.
    -   Contact your Technical Account Manager (TAM) in advance if large inorganic traffic growth is anticipated.
-   **CPU Utilization & Sizing Targets**:
    -   Maintain total CPU utilization within [recommended maximum levels](https://cloud.google.com/spanner/docs/cpu-utilization#recommended-max):
        -   **Regional Configurations**: Keep total CPU `<= 65%` and High-Priority CPU `<= 65%`.
        -   **Multi-Region / Dual-Region Configurations**: Keep total CPU `<= 45%` and High-Priority CPU `<= 45%` to reserve 55% failover headroom in case of leader or witness replica failure.
-   **Autoscaling & Pre-scaling**:
    -   Configure [Cloud Spanner Autoscaler](https://cloud.google.com/spanner/docs/autoscaling-overview) with appropriate min/max limits (`minNodes`/`maxNodes` or `minProcessingUnits`/`maxProcessingUnits`) and CPU/storage targets.
    -   **Pre-scale Instances**: Raise the minimum node/PU capacity days prior to high-traffic events rather than scaling dynamically right before traffic spikes.
-   **Client Session Pre-warming**:
    -   Allow client libraries to warm up before peak traffic. Create sessions in batch by sending synthetic queries (e.g. `SELECT 1`) across client pools to avoid session-creation latency spikes.
    -   Review [session configuration best practices](https://cloud.google.com/spanner/docs/sessions#best_practices_when_using_google_client_libraries).
-   **Managed Backups & Data Durability**:
    -   Configure automated [Backup Schedules](https://cloud.google.com/spanner/docs/backup) for regular automated protection without impacting transaction throughput.
-   **Storage Limits**:
    -   Maintain storage utilization under **70%** (max 4 TB per node / 400 GB per 100 PUs) to avoid storage-induced throttling or unexpected forced splits.
-   **Pre-splitting for Peak Capacity**:
    -   For predictable traffic surges on new or partitioned tables, [pre-split](https://cloud.google.com/spanner/docs/pre-splitting-overview) tables between 12 hours and 7 days before traffic increases so load is evenly distributed across nodes.
-   **Query Optimizer Version & Statistics**:
    -   Pin query optimizer version (`optimizer_version`) and statistics package (`optimizer_statistics_package`) temporarily prior to peak events to guarantee plan stability.
-   **Metrics & Cloud Alerting**:
    -   Set up [Cloud Alerting](https://cloud.google.com/monitoring/alerts/using-alerting-ui#create-policy) on key Cloud Spanner metrics: High-Priority CPU, Total CPU, Storage Utilization, Read/Write Latency, and API Error/Abort rates.
    -   Enable [Client-Side Metrics (CSM)](https://cloud.google.com/spanner/docs/view-manage-client-side-metrics) on supported client libraries (Java, Go, C++, Python, Node.js).
-   **Performance Testing & Hotspotting**:
    -   Inspect [Key Visualizer](https://cloud.google.com/spanner/docs/key-visualizer/patterns) heatmaps and [Lock & Transaction Insights](https://cloud.google.com/spanner/docs/use-lock-and-transaction-insights) to detect anti-patterns such as monotonically increasing primary keys or heavy lock contention.
-   **Avoid Anti-Patterns**:
    -   *Do NOT* drastically scale instances up/down during peak events (causes database split rebalancing overhead).
    -   *Do NOT* start massive client pools simultaneously without pre-warming sessions.

---

## 4. TAM & Account Readiness Checklist (Internal Only)

**Goal**: Ensure all technical and business context is gathered in advance of the event.

1.  **Identify Critical Instances & Databases**: Verify the exact list of Project Numbers, Instance IDs, and Database IDs from the customer for the event window.
2.  **Understand Business Impact**: Document event dates, anticipated peak QPS, read/write mix, and payload sizes.
3.  **Customer Capacity Assessment (CCA)**: Engage Capacity Planning / CCA if required by predicted volume.
4.  **Confirm Quota**: Verify project has sufficient regional/multi-regional node quota available.

-----

## 5. Technical Readiness Checklist for Support (Internal Only)

**Goal**: Complete technical verification and document findings on the event bug.

1.  **Gather Technical Information**:
    -   Project Number: `957928223692`
    -   Instance ID(s): `prd-s5-store`
    -   Instance Configuration (Regional / Dual-Region / Multi-Region)
    -   Databases & Dialects
2.  **Investigate Common Issues**:
    -   High CPU (`go/cloud-spanner-high-cpu`)
    -   Latencies & Lock Contention (`go/cloud-spanner-latency`)
    -   Hotspotting (`go/cloud-spanner-hotspotting`)
    -   Client Session Storms (`go/cloud-spanner-sessions`)
3.  **Check Automon Capacity**: Verify customer's Spanner instance has sufficient [node capacity & quota](http://auto/cloud:957928223692/spanner_capacity_nodes_prod/).
4.  **Document Findings**: Post summary matrix, recommendations, and risk assessment on the event bug.

-----

## 6. 🔒 Internal Support Dashboards & Telemetry (Internal Only)

The following links provide pre-populated internal support dashboards, Key Visualizer heatmaps, and capacity views for evaluated instances:

### Cloud Spanner Instance: `prd-s5-store` (`regional-europe-west2`)
- [Automon Cloud Spanner Overview Dashboard](https://automon.corp.google.com/dashboard/spanner/overview?project=957928223692&instance=prd-s5-store)
- [Automon Spanner Node Capacity Dashboard](https://automon.corp.google.com/dashboard/spanner/capacity)
- [Cloud Console Instance Overview](https://console.cloud.google.com/spanner/instances/prd-s5-store/overview?project=fc-futc-prd-gcp)
- [System Insights Dashboard](https://console.cloud.google.com/spanner/instances/prd-s5-store/system-insights?project=fc-futc-prd-gcp)
  **⚙️ Compute Capacity & 30-Day Sizing:**
  - **Min Node Count Config**: `1` nodes
  - **Max Node Count Config**: `1` nodes
  - **Recommended Max Nodes (30-Day Evaluation)**: **`2` nodes** (Optimal (Configured headroom sufficient))
