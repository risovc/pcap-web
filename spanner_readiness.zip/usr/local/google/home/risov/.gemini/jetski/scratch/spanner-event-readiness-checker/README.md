# Cloud Spanner Event Readiness Checker

A production-grade Python automation tool and Interactive Web Dashboard for Google Cloud TSGs, TAMs, and Cloud Support Engineers to perform end-to-end **Event Readiness Checks** for **Cloud Spanner** instances and databases.

---

## Features

- **Multi-Instance & Database Discovery**: Auto-discovers all Spanner instances, database dialects, backup schedules, and autoscaler configurations.
- **Topology & SLA Verification**: Differentiates Regional (99.99% SLA, <=65% CPU limit) from Dual-Region / Multi-Region (99.999% SLA, <=45% CPU limit).
- **Automated Sizing & Headroom**: Uses 30-day Monarch telemetry and autoscaler recommendations (`recommended_max_nodes`) or a 1.5x peak headroom calculation.
- **Data Durability & Backup Schedule Auditing**: Inspects both completed backups and active automated database backup schedules.
- **Query Plan Stability & Session Warmup Checks**: Flags unpinned query optimizer versions and detects cold-start session risk (<10 QPS).
- **Dual-Tab Google Doc Publishing**: Automatically creates an official Google Doc report deliverable using `/google/bin/releases/gemini-agents-gdocs/gdocs`.
- **Zero-Dependency Web Dashboard**: Lightweight built-in HTTP server with real-time log streaming and instant report links.
- **Automated IAM Auth**: Seamlessly generates inspection IAM tokens via OneSupport Hub REST API (`sso_client`).

---

## Directory Structure

```
spanner-event-readiness-checker/
├── readiness_checker.py       # Core evaluation engine, CLI, and Web UI server
├── readiness_checker_test.py  # Unit test suite (13 tests)
├── report_template.md         # Dual-tab Markdown template with placeholders
├── SKILL.md                   # Agent skill definition
├── start_web.sh               # One-click executable script to launch Web UI
└── README.md                  # Documentation and user guide
```

---

## Quick Start

### 1. Launch the Web UI
```bash
./start_web.sh
# OR
python3 readiness_checker.py --web --port=8080
```
Open `http://localhost:8080` in your browser.

### 2. Run from the CLI
```bash
# Standard Internal Evaluation
python3 readiness_checker.py \
  --project="customer-project-id" \
  --justification="b/541322397"

# Publish directly to a Google Doc
python3 readiness_checker.py \
  --project="customer-project-id" \
  --justification="vector/51234567" \
  --publish-gdoc

# Specific Instance Check
python3 readiness_checker.py \
  --project="customer-project-id" \
  --instance="my-spanner-instance" \
  --justification="b/541322397"
```

---

## Running Unit Tests

```bash
python3 readiness_checker_test.py
```
